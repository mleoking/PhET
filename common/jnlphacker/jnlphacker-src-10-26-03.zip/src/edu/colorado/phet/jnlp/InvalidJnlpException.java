/**
 * Class: InvalidJnlpException
 * Package: edu.colorado.phet.guidedinquiry.authoring
 * Author: Another Guy
 * Date: May 5, 2003
 */
package edu.colorado.phet.jnlp;

public class InvalidJnlpException extends Exception {
}
