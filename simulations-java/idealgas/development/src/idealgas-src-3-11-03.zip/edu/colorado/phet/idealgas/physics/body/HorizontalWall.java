/*
 * Class: HorizontalWall
 * Package: edu.colorado.phet.physics
 *
 * Created by: Ron LeMaster
 * Date: Dec 12, 2002
 */
package edu.colorado.phet.idealgas.physics.body;

import edu.colorado.phet.idealgas.physics.CollisionLaw;
import edu.colorado.phet.idealgas.physics.IdealGasSystem;
import edu.colorado.phet.physics.PhysicalSystem;
import edu.colorado.phet.physics.Vector2D;

import java.awt.geom.Point2D;

/**
 * A horizontally oriented wall. It's x position is undefined. When asked its x position, it reports Double.NaN
 */
public class HorizontalWall extends Wall {

    private double y;
    private CollisionLaw collisionLaw = CollisionLaw.instance();
    private Vector2D loa = new Vector2D( 0, 1 );
    private int direction;
    private Vector2D closestPtOnParticle = new Vector2D();
    private Vector2D closestPrevPtOnParticle = new Vector2D();

    public HorizontalWall( double x1, double x2, double y1, double y2, int direction ) {
        super();
        this.setLocation( x1, x2, y1, y2 );
        this.direction = direction;

        // Set the position. This is also done in setLocation, but we do it so that the previous position is initialized
        this.setPosition( Double.NaN, y1 );
    }

    public void setLocation( double x1, double x2, double y1, double y2 ) {
        if( y1 != y2 ) {
            throw new RuntimeException( "Non-horizontal coordinates specified for horizontal wall" );
        }
        super.setLocation( new Point2D.Double( x1, y1 ), new Point2D.Double( x2, y2 ) );
        this.y = y1;
        this.setPosition( Double.NaN, y1 );
    }

    public Vector2D getPosition() {
        return super.getPosition();
    }

    /**
     *
     */
    public boolean isInContactWithParticle( Particle particle ) {
        boolean isInContact = false;
        double radius = particle.getRadius();
        double positionY = particle.getPosition().getY();
        double prevPositionY = particle.getPositionPrev().getY();

        // Is the particle within the left-right bounds of the wall? Find the x coordinate of the interception
        // of the line between the particle's current position and its previous position, and the line that
        // the wall lies on. Then see if that point is in the wall

        // Determine which point on the boundary of the particle is closest to the wall.
        //closestPtOnParticle = new Vector2D( particle.getPosition() );
//        closestPrevPtOnParticle = new Vector2D( particle.getPositionPrev() );
//        if( this.y <= particle.getPositionPrev().getY() ) {
        if( this.direction == HorizontalWall.FACING_DOWN ) {
            closestPtOnParticle.setY( particle.getPosition().getY() - particle.getRadius() );
            closestPrevPtOnParticle.setY( particle.getPosition().getY()
                    - particle.getVelocity().getY() * PhysicalSystem.instance().getDt()
                    - particle.getRadius() );
//            closestPrevPtOnParticle.setY( particle.getPositionPrev().getY() - particle.getRadius() );
        }
        else {
            closestPtOnParticle.setY( particle.getPosition().getY() + particle.getRadius() );
            closestPrevPtOnParticle.setY( particle.getPosition().getY()
                    - particle.getVelocity().getY() * PhysicalSystem.instance().getDt()
                    + particle.getRadius() );
//            closestPrevPtOnParticle.setY( particle.getPositionPrev().getY() + particle.getRadius() );
        }

        double xw = xIntercept( closestPtOnParticle, closestPrevPtOnParticle );
        //double xw = xIntercept( particle.getPosition(), particle.getPositionPrev() );

        // If x intercept is NaN, that means the particle is moving parallel to the wall. Since it
        // could be wedged against the wall, or rolling along the wall, this still represents
        // contact
/*        if( Double.isNaN( xw )
            || ( xw <= this.end2.getX() && xw >= this.end1.getX() ))*/ {

            // Consider the direction the wall faces
            if( this.direction == FACING_UP
                && positionY + radius >= this.y
                && ( positionY > prevPositionY
                    || prevPositionY + radius >= this.y ) ) {
                isInContact = true;
            }
            else if( this.direction == FACING_DOWN
                && positionY - radius <= this.y
                && ( positionY < prevPositionY
                    || prevPositionY - radius <= this.y ) ) {
                isInContact = true;
            }

            /*
            // Consider a particle moving downward
            if( prevPositionY + radius < this.y
                    && positionY + radius >= this.y
                    && prevPositionY < positionY ) {
                isInContact = true;
            }

            // Consider a particle moving upward
            if( prevPositionY - radius > this.y
                    && positionY - radius <= this.y
                    && prevPositionY > positionY ) {
                isInContact = true;
            }
            */
        }

        return isInContact;
        //
        //if (Math.abs( particle.getPosition().getY() - this.y ) <= particle.getRadius()
        //    && particle.getPosition().getX() >= this.end1.getX()
        //    && particle.getPosition().getX() <= this.end2.getX() ) {
        //    return true;
        //}
        //else {
        //    return false;
        //}
    }


    // TODO: This calls isInContactWithParticle, which is inefficient
    public double getPenetrationDepth( Particle particle ) {
        double radius = particle.getRadius();
        double positionY = particle.getPosition().getY();
        double prevPositionY = particle.getPositionPrev().getY();
        double penetrationDepth = 0;

        if( this.isInContactWithParticle( particle ) ) {

            // Consider a particle moving downward
            if( prevPositionY + radius < this.y
                    && positionY + radius >= this.y
                    && prevPositionY < positionY ) {
                penetrationDepth = positionY + radius - this.y;
            }

            // Consider a particle moving upward
            if( prevPositionY - radius > this.y
                    && positionY - radius <= this.y
                    && prevPositionY > positionY ) {
                penetrationDepth = this.y - ( positionY - radius );
            }
        }
        return penetrationDepth;
    }

    public void collideWithParticle( Particle particle ) {

        IdealGasSystem idealGasSystem = (IdealGasSystem)this.getPhysicalSystem();
        if( this.direction == HorizontalWall.FACING_UP
            && ((IdealGasSystem)this.getPhysicalSystem()).getBox().containsBody( particle )
            && ((IdealGasSystem)this.getPhysicalSystem()).getBox().isOutsideBox( particle )) {
                idealGasSystem.relocateBodyY( particle, this.y - particle.getRadius() );
            }

        collisionLaw.collide( particle, this, loa );

        double sep = 0;
        sep = particle.getPosition().getY() - this.y;

        // If the particle has escaped. retrieve it
        if( this.direction == HorizontalWall.FACING_DOWN
            && ((IdealGasSystem)this.getPhysicalSystem()).getBox().containsBody( particle )
            && ((IdealGasSystem)this.getPhysicalSystem()).getBox().isOutsideBox( particle )) {
/*
            if( this.direction == HorizontalWall.FACING_UP ) {
                idealGasSystem.relocateBodyY( particle, this.y - particle.getRadius() );
            }
            else if( this.direction == HorizontalWall.FACING_DOWN ) {*/
                idealGasSystem.relocateBodyY( particle, this.y + particle.getRadius() );
//            }
        }

//        collisionLaw.collide( particle, this, loa );
    }

    /**
     * Computes the x intercept with this wall of a line connecting two points.
     */
    private double xIntercept( Vector2D p1, Vector2D p2 ) {
        double yw = this.y;
        double y1 = p1.getY();
        double y2 = p2.getY();
        double x1 = p1.getX();
        double x2 = p2.getX();

        double xw = ( x2 * ( yw - y1 ) + x1 * ( y2 - yw ) ) / ( y2 - y1 );
        return xw;
    }

    //
    // Static fields and methods
    //
    public static int FACING_UP = 1;
    public static int FACING_DOWN = 2;
}
