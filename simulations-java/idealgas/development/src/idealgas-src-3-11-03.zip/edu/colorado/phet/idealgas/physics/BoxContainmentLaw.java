// edu.colorado.phet.idealgas.physics.BoxContainmentLaw
/*
 * User: Administrator
 * Date: Jan 4, 2003
 * Time: 11:13:12 AM
 */
package edu.colorado.phet.idealgas.physics;

import edu.colorado.phet.idealgas.physics.body.Box2D;
import edu.colorado.phet.idealgas.physics.body.Particle;
import edu.colorado.phet.physics.Law;
import edu.colorado.phet.physics.PhysicalSystem;
import edu.colorado.phet.physics.body.PhysicalEntity;


public class BoxContainmentLaw implements Law {

    public void apply( double time, PhysicalSystem system ) {
    }

    public void apply( PhysicalEntity body1, PhysicalEntity body2 ) {
        Box2D box = null;
        Particle particle = null;
        if( (body1 instanceof Box2D && body2 instanceof Particle) ) {
            box = (Box2D)body1;
            particle = (Particle)body2;
        } else if(body2 instanceof Box2D && body1 instanceof Particle) {
            box = (Box2D)body1;
            particle = (Particle)body2;
        }
        if( box != null && particle != null
        && box.isOutsideBox( particle ))
        {
            box.collideWithParticle( particle );
//            double x = particle.getPosition().getX();
//            double y = particle.getPosition().getY();
//            if( particle.getPosition().getX() - particle.getRadius() < box.getMinX() ) {
//                x = box.getMinX() + particle.getRadius() + 1;
//            }
//            if( particle.getPosition().getY() - particle.getRadius() < box.getMinY() ) {
//                y = box.getMinY() + particle.getRadius() + 1;
//            }
//            if( particle.getPosition().getX() + particle.getRadius() > box.getMaxX() ) {
//                x = box.getMaxX() - particle.getRadius() - 1;
//            }
//            if( particle.getPosition().getY() + particle.getRadius() > box.getMaxY() ) {
//                y = box.getMaxY() - particle.getRadius() - 1;
//            }
//            particle.setPosition( x, y );
        }
    }
}
