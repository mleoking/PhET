package edu.colorado.phet.idealgas.physics.body;

import edu.colorado.phet.idealgas.physics.Collidable;
import edu.colorado.phet.physics.PhysicalSystem;
import edu.colorado.phet.physics.Vector2D;
import edu.colorado.phet.physics.body.Particle;

/**
 * This abstract class represents physical bodies. It is abstract so that only
 * subclasses can be instantiated, forcing them to declare if they do or do not
 * have physical extent.
 */
public abstract class CollidableBody extends Particle implements Collidable {


    /**
     * Constructors
     */
    protected CollidableBody() {
        this( new Vector2D(), new Vector2D(), new Vector2D(), s_defaultMass );
    }

    protected CollidableBody( Vector2D position, Vector2D velocity,
                    Vector2D acceleration, double mass ) {
        this( position, velocity, acceleration, mass, s_defaultCharge );
    }

    protected CollidableBody( Vector2D position, Vector2D velocity,
                    Vector2D acceleration, double mass, double charge ) {

        this.position = position;
        this.velocity = velocity;
//        setVelocity( velocity );
        this.acceleration = acceleration;
        this.mass = mass;
        this.charge = charge;

        // Set previous position based on current position and velocity
        double prevX = position.getX() - velocity.getX() * PhysicalSystem.instance().getDt();
        double prevY = position.getY() - velocity.getY() * PhysicalSystem.instance().getDt();
        this.positionPrev = new Vector2D( prevX, prevY );

        this.velocityPrev = new Vector2D( velocity );
        this.accelerationPrev = new Vector2D( acceleration );
        this.massPrev = mass;
        this.chargePrev = charge;

        this.positionInitial = new Vector2D( position );
        this.velocityInitial = new Vector2D( velocity );
        this.accelerationInitial = new Vector2D( acceleration );
        this.massInitial = mass;
        this.chargeInitial = charge;
    }


    // Returns the distance from the body's center that it makes contact
    // with other bodies. This is, or course, an over-simplified approach,
    // and only works with walls and spheres.
    abstract public double getContactOffset( CollidableBody body );
}
