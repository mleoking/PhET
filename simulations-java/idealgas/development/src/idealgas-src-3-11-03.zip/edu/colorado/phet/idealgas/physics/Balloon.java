/**
 * Created by IntelliJ IDEA.
 * User: Another Guy
 * Date: Jan 15, 2003
 * Time: 1:53:09 PM
 * To change this template use Options | File Templates.
 */
package edu.colorado.phet.idealgas.physics;

import edu.colorado.phet.idealgas.physics.body.Box2D;
import edu.colorado.phet.idealgas.physics.body.HollowSphere;
import edu.colorado.phet.idealgas.physics.body.Particle;
import edu.colorado.phet.physics.Vector2D;

public class Balloon extends HollowSphere {

    private PressureRecorder insidePressureRecorder = new PressureRecorder();
    private PressureRecorder outsidePressureRecorder = new PressureRecorder();

    public Balloon( Vector2D center,
                    Vector2D velocity,
                    Vector2D acceleration,
                    double mass,
                    double radius ) {
        super( center, velocity, acceleration, mass, radius );
    }

    public void reInitialize() {
        super.reInitialize();
        insidePressureRecorder.clear();
        outsidePressureRecorder.clear();
    }

    /**
     * Records the impact on the inside or outside of the balloon
     */
    private Vector2D momentumPre = new Vector2D();
    private Vector2D momentumPost = new Vector2D();
    public void collideWithParticle( Particle particle ) {

//        super.collideWithParticle( particle );

        // Get the momentum of the balloon before the collision
        momentumPre.setX( getVelocity().getX() );
        momentumPre.setY( getVelocity().getY() );
        momentumPre = momentumPre.multiply( this.getMass() );

        // Perform the collision
        super.collideWithParticle( particle );

        // Get the new momentum of the balloon
        momentumPost.setX( this.getVelocity().getX() );
        momentumPost.setY( this.getVelocity().getY() );
        momentumPost = momentumPost.multiply( this.getMass() );

        // Compute the change in momentum and record it as pressure
        Vector2D momentumChange = momentumPost.subtract( momentumPre );
        double impact = momentumChange.getLength();
        PressureRecorder recorder = this.containsBody( particle )
                ? insidePressureRecorder
                : outsidePressureRecorder;
        recorder.addPressureRecordEntry( impact );

//        System.out.println( "inner pressure: " + insidePressureRecorder.getPressure()
//                            + "   outside pressure: " + outsidePressureRecorder.getPressure() );

    }

    public double getInsidePressure() {
        return insidePressureRecorder.getPressure();
    }

    public double getOutsidePressure() {
        return outsidePressureRecorder.getPressure();
    }

    private int timeStepsSinceLastRadiusAdjustment = 0;
//    private int timeStepsBetweenRadiusAdjustments = 50;
    private int timeStepsBetweenRadiusAdjustments = 20;
    private double aveInOutPressureRatio = 0;
    private double dampingFactor = 0.1;

    public void stepInTime( double dt ) {

        super.stepInTime( dt );

        // Compute average pressure differential
        double currInOutPressureRatio = insidePressureRecorder.getPressure() / outsidePressureRecorder.getPressure();

        if( !Double.isNaN( currInOutPressureRatio )
                && currInOutPressureRatio != 0
                && currInOutPressureRatio != Double.POSITIVE_INFINITY
                && currInOutPressureRatio != Double.NEGATIVE_INFINITY ) {
            aveInOutPressureRatio = ( ( aveInOutPressureRatio * timeStepsSinceLastRadiusAdjustment )
                    + ( insidePressureRecorder.getPressure() / outsidePressureRecorder.getPressure() ) )
                    / ( ++timeStepsSinceLastRadiusAdjustment );
        }

        // Adjust the radius of the balloon
        //Make sure the balloon doesn't expand beyond the box
        Box2D box = ((IdealGasSystem)this.getPhysicalSystem()).getBox();
//        double maxRadius = Math.min( Math.min( Math.abs( box.getMaxX() - this.getCenter().getX()),
//                             Math.abs( box.getMinX() - this.getCenter().getX()) ),
//                           Math.min( Math.abs( box.getMaxY() - this.getCenter().getY()),
//                             Math.abs( box.getMinY() - this.getCenter().getY()) ));
        double maxRadius = Math.min( ( box.getMaxX() - box.getMinX() ) / 2,
                           ( box.getMaxY() - box.getMinY()) / 2 );
        if( timeStepsSinceLastRadiusAdjustment >= timeStepsBetweenRadiusAdjustments ) {
            timeStepsSinceLastRadiusAdjustment = 0;

            double newRadius =  Math.min( this.getRadius() * Math.pow( aveInOutPressureRatio, dampingFactor ), maxRadius );
            if( !Double.isNaN( newRadius )) {
                newRadius = Math.max( newRadius, 20 );
                this.setRadius( newRadius );
            }
//            else {
//                this.setRadius( maxRadius );
//            }
        }
//        else if( maxRadius < this.getRadius() ) {
//            this.setRadius( maxRadius );
//
//        }

    }


}

