/*
 * Class: PressureSensingBox
 * Package: edu.colorado.phet.physicaldomain.idealgas
 *
 * Created by: Ron LeMaster
 * Date: Oct 29, 2002
 */
package edu.colorado.phet.idealgas.physics;

import edu.colorado.phet.idealgas.physics.body.Box2D;
import edu.colorado.phet.idealgas.physics.body.CollidableBody;
import edu.colorado.phet.idealgas.physics.body.Particle;
import edu.colorado.phet.physics.PhysicalSystem;
import edu.colorado.phet.physics.Vector2D;

/**
 *
 */
public class PressureSensingBox extends Box2D {

    private PressureRecorder pressureRecorder = new PressureRecorder();

    /**
     * Constructor
     */
    public PressureSensingBox( Vector2D corner1, Vector2D corner2 ) {
        super( corner1, corner2 );
    }

    public void setPhysicalSystem( PhysicalSystem physicalSystem ) {
        super.setPhysicalSystem( physicalSystem );
    }

    /**
     *
     */
    public void clear() {
        pressureRecorder.clear();
    }

    /**
     *
     */
    public double getPressure() {
        return pressureRecorder.getPressure();
    }

    /**
     *
     */
    public void collideWithBody( CollidableBody body ) {
        recordImpact( (Particle)body );
        body.collideWithBox2D( this );
    }

    /**
     * TODO: rewrite this to use methods in BOX2D that find closest wall
     * @param particle
     */
    private void recordImpact( Particle particle ) {

        double newVeloctyX = particle.getVelocity().getX();
        double newVeloctyY = particle.getVelocity().getY();
        double particleMomentum = 0;

        // Determine which wall of the box the particle is colliding with
        Vector2D closestCorner = this.getClosestCorner( particle.getPosition() );

        // Is it colliding with a corner?
        if( Math.abs( Math.abs( closestCorner.getX() - particle.getPosition().getX() )
                      - Math.abs( closestCorner.getY() - particle.getPosition().getY() ) )
                < s_collisionTolerance ) {
            particleMomentum += Math.abs( newVeloctyX ) * particle.getMass();
            particleMomentum += Math.abs( newVeloctyY ) * particle.getMass();
        }

        // Colliding with a vertical wall?
        else if( Math.abs( closestCorner.getX() - particle.getPosition().getX() )
                < Math.abs( closestCorner.getY() - particle.getPosition().getY() ) ) {
            particleMomentum += Math.abs( newVeloctyX ) * particle.getMass();
        }

        // It must be colliding with a horizontal wall
        else {
            particleMomentum += Math.abs( newVeloctyY ) * particle.getMass();
        }

        //this.addPressureRecordEntry( particle.getClass(), particleMomentum );
        this.pressureRecorder.addPressureRecordEntry( particleMomentum );
    }

    //
    // Static fields and methods
    //
    double s_collisionTolerance = 2.0;
}
