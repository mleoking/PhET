/*
 * Class: GasMoleculeGraphic
 * Package: edu.colorado.phet.graphics.idealgas
 *
 * Created by: Ron LeMaster
 * Date: Nov 4, 2002
 */
package edu.colorado.phet.idealgas.graphics;

import java.awt.*;

/**
 *
 */
public class GasMoleculeGraphic extends edu.colorado.phet.idealgas.graphics.ParticleGraphic {

    protected void setRep( Object rep ) {
        super.setRep( rep );
    }

    public void paint( Graphics2D g ) {

        super.paint( g );
    }
}
