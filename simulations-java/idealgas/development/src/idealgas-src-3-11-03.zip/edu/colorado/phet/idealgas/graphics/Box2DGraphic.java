// Box2DGraphic

/*
 * User: Ron LeMaster
 * Date: Oct 18, 2002
 * Time: 10:55:17 AM
 */
package edu.colorado.phet.idealgas.graphics;

import edu.colorado.phet.idealgas.graphics.IdealGasApparatusPanel;
import edu.colorado.phet.physics.Clock;
import edu.colorado.phet.physics.Vector2D;
import edu.colorado.phet.physics.PhysicalSystem;
import edu.colorado.phet.physics.body.Particle;
import edu.colorado.phet.idealgas.physics.body.CollidableBody;
import edu.colorado.phet.idealgas.physics.body.Box2D;
import edu.colorado.phet.idealgas.physics.PressureSensingBox;
import edu.colorado.phet.idealgas.graphics.IdealGasApparatusPanel;
import edu.colorado.phet.graphics.ShapeGraphic;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Rectangle2D;
import java.util.Observable;

public class Box2DGraphic extends ShapeGraphic implements MouseListener, MouseMotionListener {

    private int stroke;

    public Box2DGraphic() {
        super( s_defaultColor, s_defaultStroke );
        init();
    }

    public Box2DGraphic( Box2D box ) {
        super( s_defaultColor, s_defaultStroke );
        init();
        init( box );
        setPosition( box );
    }

    private void init() {
        this.setRep( new Rectangle2D.Double() );
    }

    private IdealGasApparatusPanel getIdealGasApparatusPanel() {
        return (IdealGasApparatusPanel)getApparatusPanel();
    }

    private double lastPressure = 0;

    /**
     * Notes state change in the box the receiver is observing. Changes
     * the position of the leaning man if the pressure in the box has
     * changed sufficiently
     * @param o
     * @param arg
     */
    public void update( Observable o, Object arg ) {
        this.setPosition( (CollidableBody)o );
        if( o instanceof PressureSensingBox ) {
            PressureSensingBox box = (PressureSensingBox)o;
            double newPressure = box.getPressure();
            if( newPressure > lastPressure * s_leaningManStateChangeScaleFactor ) {
                getIdealGasApparatusPanel().moveLeaner( 1 );
                lastPressure = box.getPressure();
            } else if( newPressure < lastPressure / s_leaningManStateChangeScaleFactor ) {
                getIdealGasApparatusPanel().moveLeaner( -1 );
                lastPressure = box.getPressure();
            }
        }
    }

    protected void setPosition( Particle body ) {
        Rectangle2D rep = (Rectangle2D)this.getRep();
        Box2D box = (Box2D)body;
        double prevLeftWallX = rep.getMinX();
        rep.setFrameFromDiagonal(
                getApparatusPanel().worldToScreenX( box.getCorner1X() ),
                getApparatusPanel().worldToScreenY( box.getCorner1Y() ),
                getApparatusPanel().worldToScreenX( box.getCorner2X() ),
                getApparatusPanel().worldToScreenY( box.getCorner2Y() ) );
        double currLeftWallX = rep.getMinX();
        int dir = (int)( Math.abs( currLeftWallX - prevLeftWallX ) / ( currLeftWallX - prevLeftWallX ) );
        this.getIdealGasApparatusPanel().movePusher( dir );
    }

    /**
     *
     */
    Rectangle2D.Double openingShape = new Rectangle2D.Double();

    public void paint( Graphics2D g ) {
        super.paint( g );

        Color oldColor = g.getColor();
        g.setColor( Color.WHITE );
        Box2D box = (Box2D)this.getBody();
        Vector2D[] opening = box.getOpening();
        openingShape.setRect( opening[0].getX(), opening[0].getY(),
                              opening[1].getX() - opening[0].getX(),
                              opening[1].getY() - opening[0].getY()
        );
        g.draw( openingShape );
        g.setColor( oldColor );
    }

    //
    // Mouse-related methods
    //
    private boolean dragging = false;
    private boolean isInHotSpot = false;
    private double lastMinX = 0;
    private long lastEventTime = 0;
    private double clockScaleFactor = 0;
    private boolean initWallMovement = false;


    public void mouseClicked( MouseEvent event ) {
    }

    public void mousePressed( MouseEvent event ) {

        // If the click is over the box, then start dragging
        if( isInHotSpot ) {
            getApparatusPanel().setCursor( Cursor.getPredefinedCursor( Cursor.W_RESIZE_CURSOR ) );
            dragging = true;
        }
    }

    public void mouseReleased( MouseEvent event ) {
        dragging = false;

        // Make sure the wall knows it's not moving anymore
        ( (Box2D)getBody() ).setLeftWallVelocity( 0 );
    }

    public void mouseEntered( MouseEvent event ) {
    }

    public void mouseExited( MouseEvent event ) {
    }

    /**
     * Tracks the movement of the the left edge of the box wwhen it's dragged
     */
    public void mouseDragged( MouseEvent event ) {

        if( dragging ) {

            Rectangle2D.Double boxGraphic = (Rectangle2D.Double)this.getRep();
            double t = event.getPoint().getX();
            t = Math.max( event.getPoint().getX(), 50 );
            t = Math.min( Math.max( event.getPoint().getX(), 50 ), boxGraphic.getMaxX() - 20 );
            boxGraphic.setFrameFromDiagonal(
                    Math.min( Math.max( event.getPoint().getX(), 50 ), boxGraphic.getMaxX() - 20 ),
                    boxGraphic.getMinY(),
                    boxGraphic.getMaxX(),
                    boxGraphic.getMaxY() );
            Box2D box = (Box2D)this.getBody();
            box.setBounds(
                    boxGraphic.getMinX(),
                    boxGraphic.getMinY(),
                    boxGraphic.getMaxX(),
                    boxGraphic.getMaxY() );

            // Compute the velocity of the wall
            if( !initWallMovement ) {
                initWallMovement = true;

                lastMinX = event.getPoint().getX();
                lastEventTime = event.getWhen();
                clockScaleFactor = PhysicalSystem.instance().getDt() / PhysicalSystem.instance().getWaitTime();
            }
            double dx = event.getPoint().getX() - lastMinX;
            lastMinX = event.getPoint().getX();
            long now = event.getWhen();
            long dt = now - lastEventTime;
            lastEventTime = now;
            if( dt > 0 ) {
                double vx = dx / ( dt * clockScaleFactor );
                Thread.yield();
                box.setLeftWallVelocity( vx * 2 );
                // We must yield so the PhysicalSystem thread can get the
                // update.
                Thread.yield();
            }

            this.getIdealGasApparatusPanel().movePusher( (int)( Math.abs( dx ) / dx ) );
            return;
        }
    }

    public void mouseMoved( MouseEvent event ) {

        Point mousePos = event.getPoint();

        // Determine the screen location of the box
        Rectangle2D.Double box = (Rectangle2D.Double)this.getRep();
        Rectangle2D.Double hotSpot;
        if( Math.abs( mousePos.getX() - box.getMinX() ) < 5
                && ( mousePos.getY() <= box.getMaxY() && mousePos.getY() >= box.getMinY() ) ) {
            getApparatusPanel().setCursor( Cursor.getPredefinedCursor( Cursor.HAND_CURSOR ) );
            isInHotSpot = true;
        } else if( isInHotSpot ) {
            getApparatusPanel().setCursor( Cursor.getDefaultCursor() );
            isInHotSpot = false;
        }
    }

    public boolean isDragging() {
        return dragging;
    }

    //
    // Static fields and methods
    //
    private static Stroke s_defaultStroke = new BasicStroke( 8.0F );
    private static Color s_defaultColor = Color.black;
    private static float s_leaningManStateChangeScaleFactor = 1.75F;
}
