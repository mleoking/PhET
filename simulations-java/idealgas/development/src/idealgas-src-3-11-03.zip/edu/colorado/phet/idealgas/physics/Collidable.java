/*
 * Interface: Collidable
 * Package: edu.colorado.phet.physics
 *
 * Created by: Ron LeMaster
 * Date: Nov 1, 2002
 */
package edu.colorado.phet.idealgas.physics;

import edu.colorado.phet.idealgas.physics.body.Box2D;
import edu.colorado.phet.idealgas.physics.body.CollidableBody;
import edu.colorado.phet.idealgas.physics.body.HollowSphere;
import edu.colorado.phet.idealgas.physics.body.Particle;

/**
 *
 */
public interface Collidable {

    public boolean isInContactWithBody( CollidableBody body );

    public boolean isInContactWithParticle( Particle particle );

    public boolean isInContactWithBox2D( Box2D box );

    public boolean isInContactWithHollowSphere( HollowSphere sphere );

    public boolean isInContactWithHotAirBalloon( HotAirBalloon hotAirBalloon );

    public void collideWithBody( CollidableBody body );

    public void collideWithParticle( Particle particle );

    public void collideWithBox2D( Box2D box );

    public void collideWithHollowSphere( HollowSphere sphere );
}
