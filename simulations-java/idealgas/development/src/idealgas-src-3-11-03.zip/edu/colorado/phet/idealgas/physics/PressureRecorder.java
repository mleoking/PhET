/**
 * Created by IntelliJ IDEA.
 * User: Another Guy
 * Date: Jan 15, 2003
 * Time: 1:56:39 PM
 * To change this template use Options | File Templates.
 */
package edu.colorado.phet.idealgas.physics;

import edu.colorado.phet.physics.PhysicalSystem;

import java.util.Iterator;
import java.util.LinkedList;

public class PressureRecorder {
    private LinkedList pressureRecord = new LinkedList();
    private double pressure;


    /**
     *
     */
    public void clear() {
        pressureRecord.removeAll( pressureRecord );
    }

    /**
     *
     */
    public double getPressure() {
        return pressure;
    }

    private double computePressure( LinkedList pressureRecord ) {

        double totalImpact = 0;

        // If there aren't at least two entries in the list, we can't compute the
        // pressure
        if( pressureRecord.size() >= 2 ) {
            double t1 = ((PressureRecordEntry)pressureRecord.getFirst()).getTime();
            double t2 = ((PressureRecordEntry)pressureRecord.getLast()).getTime();
            for( Iterator pressureIt = pressureRecord.iterator(); pressureIt.hasNext(); ) {
                PressureRecordEntry entry = (PressureRecordEntry)pressureIt.next();
                totalImpact += entry.getMomentum();
            }

            // We must get the momentum change per unit time. If we don't do this, the number
            // we get is not meaningful
            totalImpact /= (t2 - t1 );
        }
        return totalImpact;
    }

    /**
     *
     */
    public void addPressureRecordEntry( double impact ) {

        if( pressureRecord.size() > s_pressureRecordLength ) {
            pressureRecord.removeFirst();
        }
        PressureRecordEntry entry = new PressureRecordEntry(
                PhysicalSystem.instance().getRunningTime(), impact );
        pressureRecord.addLast( entry );
        pressure = computePressure( pressureRecord );
    }

    //
    // Static fields and methods
    //
    double s_pressureRecordLength = 50;
//    double s_pressureRecordLength = 100;

    //
    // Inner classes
    //

    /**
     * Class for entries in the time-based pressure record list
     */
    private class PressureRecordEntry {

        private double time;
        private double momentum;

        PressureRecordEntry( double time, double momentum ) {
            this.time = time;
            this.momentum = momentum;
        }

        public double getTime() {
            return time;
        }

        public double getMomentum() {
            return momentum;
        }
    }

}
