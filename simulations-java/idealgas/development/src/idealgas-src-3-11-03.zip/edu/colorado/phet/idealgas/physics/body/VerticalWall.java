/*
 * Class: HorizontalWall
 * Package: edu.colorado.phet.physics
 *
 * Created by: Ron LeMaster
 * Date: Dec 12, 2002
 */
package edu.colorado.phet.idealgas.physics.body;

import edu.colorado.phet.idealgas.physics.CollisionLaw;
import edu.colorado.phet.idealgas.physics.IdealGasSystem;
import edu.colorado.phet.physics.PhysicalSystem;
import edu.colorado.phet.physics.Vector2D;

import java.awt.geom.Point2D;

/**
 * A vertically oriented wall. It's y position is undefined. When asked its y position, it reports Double.NaN
 */
public class VerticalWall extends Wall {

    private double x;
    private Vector2D loa = new Vector2D( 1, 0 );
    private CollisionLaw collisionLaw = CollisionLaw.instance();
    private int direction;
    private Vector2D closestPtOnParticle = new Vector2D();
    private Vector2D closestPrevPtOnParticle = new Vector2D();

    /**
     *
     */
    public VerticalWall( double x1, double x2, double y1, double y2, int direction ) {

        super();
        this.setLocation( x1, x2, y1, y2 );
        this.direction = direction;

        // Set the position. This is also done in setLocation, but we do it so that the previous position is initialized
        this.setPosition( x1, Double.NaN );
    }

    /**
     *
     */
    public void setLocation( double x1, double x2, double y1, double y2 ) {
        if( x1 != x2 ) {
            throw new RuntimeException( "Non-vertical coordinates specified for vertical wall" );
        }
        super.setLocation( new Point2D.Double( x1, y1 ), new Point2D.Double( x2, y2 ) );
        this.x = x1;
        this.setPosition( x1, Double.NaN );
    }

    /**
     *
     */
    public boolean isInContactWithParticle( Particle particle ) {
        boolean isInContact = false;
        double radius = particle.getRadius();
        double positionX = particle.getPosition().getX();
        double prevPositionX = particle.getPositionPrev().getX();

        // Is the particle within the up-down bounds of the wall? Find the y coordinate of the interception
        // of the line between the particle's current position and its previous position, and the line that
        // the wall lies on. Then see if that point is in the wall

        // Determine which point on the boundary of the particle is closest to the wall.
//        closestPtOnParticle = new Vector2D( particle.getPosition() );
//        closestPrevPtOnParticle = new Vector2D( particle.getPositionPrev() );
//        if( this.x <= particle.getPositionPrev().getX() ) {
        if( this.direction == VerticalWall.FACING_RIGHT ) {
            closestPtOnParticle.setX( particle.getPosition().getX() - particle.getRadius() );
            closestPrevPtOnParticle.setX( particle.getPosition().getX()
                    - particle.getVelocity().getX() * PhysicalSystem.instance().getDt()
                    - particle.getRadius() );
//            closestPrevPtOnParticle.setX( particle.getPositionPrev().getX() - particle.getRadius() );
        }
        else {
            closestPtOnParticle.setX( particle.getPosition().getX() + particle.getRadius() );
            closestPrevPtOnParticle.setX( particle.getPosition().getX()
                    - particle.getVelocity().getX() * PhysicalSystem.instance().getDt()
                    + particle.getRadius() );
//            closestPrevPtOnParticle.setX( particle.getPositionPrev().getX() + particle.getRadius() );
        }

        double yw = yIntercept( closestPtOnParticle, closestPrevPtOnParticle );
        //double yw = yIntercept( particle.getPosition(), particle.getPositionPrev() );

        // Took out test for endpoints to fix problem with corners. See notes from London,
        // 12/26/02
        // If y intercept is NaN, that means the particle is moving parallel to the wall. Since it
        // could be wedged against the wall, or rolling along the wall, this still represents
        // contact
/*        if( Double.isNaN( yw )
            || yw <= this.end2.getY() && yw >= this.end1.getY() ) */ {
        //if( particle.getPositionPrev().getY() <= this.end2.getY()
        //        && particle.getPosition().getY() >= this.end1.getY() ) {

            // Consider the direction the wall faces and the direction the particle
            // is traveling
            if( this.direction == FACING_LEFT
                && positionX + radius >= this.x
                && ( positionX > prevPositionX
                    || prevPositionX + radius >= this.x )) {
                isInContact = true;
            }
            else if( this.direction == FACING_RIGHT
                && positionX - radius <= this.x
                && ( positionX < prevPositionX
                    || prevPositionX - radius <= this.x )) {
                isInContact = true;
            }

            /*
            // Consider a particle moving to the right
            if( prevPositionX < positionX
                    && positionX + radius >= this.x
                    && prevPositionX + radius < this.x ) {
                isInContact = true;
            }

            // Consider a particle moving to the left
            if( prevPositionX > positionX
                    && prevPositionX - radius > this.x
                    && positionX - radius <= this.x ) {
                isInContact = true;
            }
            */
        }
        return isInContact;

        //if (Math.abs( particle.getPosition().getX() - this.x ) <= particle.getRadius()
        //    && particle.getPosition().getY() >= this.end1.getY()
        //    && particle.getPosition().getY() <= this.end2.getY() ) {
        //    return true;
        //}
        //else {
        //    return false;
        //}
    }


    public double getPenetrationDepth( Particle particle ) {
        double radius = particle.getRadius();
        double positionX = particle.getPosition().getX();
        double penetrationDepth = Math.abs( positionX + radius - this.x );
        return penetrationDepth;
    }

    public void collideWithParticle( Particle particle ) {

        double sep = 0;
        sep = particle.getPosition().getX() - this.x;

        // If the particle has escaped. retrieve it
        if( ((IdealGasSystem)this.getPhysicalSystem()).getBox().containsBody( particle ) ) {

            if( this.direction == VerticalWall.FACING_LEFT && sep >= 0 ) {
                particle.setPositionX( this.x - particle.getRadius() );
            }
            else if( this.direction == VerticalWall.FACING_RIGHT && sep <= 0 ) {
                particle.setPositionX( this.x + particle.getRadius() );
            }
        }
        collisionLaw.collide(  particle, this, loa );
    }

    /**
     * Computes the y intercept with this wall of a line connecting two points.
     */
    private double yIntercept( Vector2D p1, Vector2D p2 ) {
        double xw = this.x;
        double y1 = p1.getY();
        double y2 = p2.getY();
        double x1 = p1.getX();
        double x2 = p2.getX();

        double yw = ( y2 * ( xw - x1 ) + y1 * ( x2 - xw ) ) / ( x2 - x1 );
        return yw;
    }

    //
    // Static fields and methods
    //
    public static int FACING_LEFT = 1;
    public static int FACING_RIGHT = 2;
}
