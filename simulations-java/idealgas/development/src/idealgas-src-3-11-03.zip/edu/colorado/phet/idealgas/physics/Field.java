package edu.colorado.phet.idealgas.physics;

import edu.colorado.phet.physics.body.PhysicalEntity;

/**
 * Created by IntelliJ IDEA.
 * User: Another Guy
 * Date: Mar 11, 2003
 * Time: 10:20:26 AM
 * To change this template use Options | File Templates.
 */
public abstract class Field extends PhysicalEntity {

}
