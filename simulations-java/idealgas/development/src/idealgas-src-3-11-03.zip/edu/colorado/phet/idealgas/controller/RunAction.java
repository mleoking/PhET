/**
 * Created by IntelliJ IDEA.
 * User: Another Guy
 * Date: Feb 13, 2003
 * Time: 4:09:20 PM
 * To change this template use Options | File Templates.
 */
package edu.colorado.phet.idealgas.controller;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class RunAction extends AbstractAction {

    public void actionPerformed( ActionEvent e ) {
    }
}
