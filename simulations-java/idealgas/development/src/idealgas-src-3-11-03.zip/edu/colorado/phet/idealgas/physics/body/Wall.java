/*
 * Class: Wall
 * Package: edu.colorado.phet.physics
 *
 * Created by: Ron LeMaster
 * Date: Dec 12, 2002
 */
package edu.colorado.phet.idealgas.physics.body;

import edu.colorado.phet.idealgas.physics.HotAirBalloon;
import edu.colorado.phet.physics.Vector2D;

import java.awt.geom.Point2D;

/**
 *
 */
public class Wall extends CollidableBody {

    Point2D.Double end1;
    Point2D.Double end2;

    // The line of action unit vector that another body would have if it contacted the wall
    private Vector2D loaUnit;

    protected Wall() {
        super();
        init();
    }

    public Wall( Point2D.Double end1, Point2D.Double end2 ) {
        super();
        init();
        this.setLocation( end1, end2 );
    }

    private void init() {
        // Set the velocity twice so the previous velocity gets set
        this.setVelocity( 0, 0 );
        this.setVelocity( 0, 0 );
    }

    protected void setLocation( Point2D.Double end1, Point2D.Double end2 ) {
        this.end1 = end1;
        this.end2 = end2;
        setLoaUnit();
    }

    public void setLocation( double x1, double x2, double y1, double y2 ) {
        end1.setLocation( x1, y1 );
        end2.setLocation( x2, y2 );
    }

    private void setLoaUnit() {
        loaUnit = new Vector2D( end2.getY() - end1.getY(), end2.getX() - end1.getX() ).normalize();
    }

    public Vector2D getLoaUnit( Particle particle ) {
        return loaUnit;
    }

    //
    // Abstract methods
    //
    public boolean isInContactWithBody( CollidableBody body ) {
        return false;
    }

    public boolean isInContactWithParticle( Particle particle ) {
        return false;
    }

    public boolean isInContactWithBox2D( Box2D box ) {
        return false;
    }

    public boolean isInContactWithHollowSphere( HollowSphere sphere ) {
        return false;
    }

    public boolean isInContactWithHotAirBalloon( HotAirBalloon hotAirBalloon ) {
        return false;
    }

    public void collideWithBody( CollidableBody body ) {
    }

    public void collideWithParticle( Particle particle ) {
    }

    public void collideWithBox2D( Box2D box ) {
    }

    public void collideWithHollowSphere( HollowSphere sphere ) {
    }

    // Returns the distance from the body's center that it makes contact
    // with other bodies. This is, or course, an over-simplified approach,
    // and only works with walls and spheres.
    public double getContactOffset( CollidableBody body ) {
        return 0;
    }
}

