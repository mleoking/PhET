package edu.colorado.phet.idealgas.controller;

import edu.colorado.phet.idealgas.physics.body.Particle;
import edu.colorado.phet.controller.Command;

/**
 * Created by IntelliJ IDEA.
 * User: Another Guy
 * Date: Mar 7, 2003
 * Time: 12:52:28 PM
 * To change this template use Options | File Templates.
 */
public class RemoveParticleCommand implements Command {

    private Particle particle;

    public RemoveParticleCommand( Particle particle ) {
        this.particle = particle;
    }

    public Object doIt( Object obj ) {
        particle.removeFromSystem();
        return null;
    }
}
