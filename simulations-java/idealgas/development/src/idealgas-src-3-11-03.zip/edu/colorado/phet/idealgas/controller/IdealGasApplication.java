/*
 * Class: IdealGasApplication
 * Package: edu.colorado.phet.idealgas.controller
 *
 * Created by: Ron LeMaster
 * Date: Nov 6, 2002
 */
package edu.colorado.phet.idealgas.controller;

import edu.colorado.phet.controller.*;
import edu.colorado.phet.idealgas.controller.IdealGasConfig;
import edu.colorado.phet.idealgas.physics.*;
import edu.colorado.phet.idealgas.graphics.IdealGasGraphicFactory;
import edu.colorado.phet.idealgas.graphics.IdealGasAboutDialog;
import edu.colorado.phet.idealgas.graphics.IdealGasApparatusPanel;
import edu.colorado.phet.physics.*;
import edu.colorado.phet.idealgas.physics.body.Box2D;
import edu.colorado.phet.graphics.GraphicFactory;

import javax.swing.*;

/**
 *
 */
public class IdealGasApplication extends PhetApplication {

    private Class currentGasSpecies = HeavySpecies.class;
    private boolean cmLinesOn;


    public void clear() {
        super.clear();
        getIdealGasSystem().setGravity( null );
        ((IdealGasApparatusPanel)getPhetMainPanel().getApparatusPanel()).closeDoor();
    }

    public IdealGasApplication() {
        super( new IdealGasSystem() );
        init();

        // Start the application running
        this.run();
    }

    /**
     *
     */
    public void init() {
        super.init();

        // Add a pressure box
        double xOrigin = 132 + IdealGasConfig.X_BASE_OFFSET;
        double yOrigin = 252 + IdealGasConfig.Y_BASE_OFFSET;
        double xDiag = 434 + IdealGasConfig.X_BASE_OFFSET;
        double yDiag = 497 + IdealGasConfig.Y_BASE_OFFSET;
        PressureSensingBox box = new PressureSensingBox(
                new Vector2D( xOrigin, yOrigin ),
                new Vector2D( xDiag, yDiag ) );
        this.addBox( box, 1 );

        // Add a collision law
        this.addLaw( CollisionLaw.instance() );
        this.addLaw( new BoxContainmentLaw() );

        // Set the default clock
        this.setClockParams( 0.1, 20, 0.0 );
    }

    /**
     *
     */
    public GraphicFactory getGraphicFactory() {
        return IdealGasGraphicFactory.instance();
    }

    /**
     *
     */
    protected PhetMainPanel createMainPanel() {
        return new IdealGasMainPanel( this );
    }

    /**
     *
     */
    public IdealGasSystem getIdealGasSystem() {
        return (IdealGasSystem)getPhysicalSystem();
    }

    /**
     *
     */
    public void addBox( Box2D box, int level ) {
        this.getIdealGasSystem().addBox( box );
        this.addBody( box, level );
    }

    /**
     *
     */
    public void setGravity( Gravity gravity ) {
        getIdealGasSystem().setGravity( gravity );
    }

    /**
     *
     */
    public void setGravity( double amt ) {
        if( getIdealGasMainPanel() != null ) {
            ((IdealGasControlPanel)getIdealGasMainPanel().getControlPanel()).
                    setGravity( amt );
        }
    }

    /**
     *
     */
    public void setGravityEnabled( boolean enabled ) {
        if( getIdealGasMainPanel() != null ) {
            ((IdealGasControlPanel)getIdealGasMainPanel().getControlPanel()).
                    setGravityEnabled( enabled );
        }
    }

    /**
     * Sets the species of gas that will be used when gas is introducted into the system
     */
    public void setCurrentSpecies( Class gasSpecies ) {

        // Sanity check on the parameter
        if( !GasMolecule.class.isAssignableFrom( gasSpecies ) ) {
            throw new RuntimeException( "Parameter of incompatible type. Required: " + GasMolecule.class
                    + "  Received: " + gasSpecies );
        }
        currentGasSpecies = gasSpecies;
    }

    /**
     *
     */
    public Class getCurrentGasSpecies() {
        return currentGasSpecies;
    }

    /**
     * Sets an attribute to tell whether to display CM lines
     */
    public void setCmLinesOn( boolean b ) {
        cmLinesOn = b;
    }

    /**
     *
     */
    public boolean isCmLinesOn() {
        return cmLinesOn;
    }

    /**
     *
     */
    public void setStove( int value ) {
        this.getIdealGasMainPanel().setStove( value );
        this.getIdealGasSystem().setHeatSource( (double)value );
    }

    /**
     *
     */
    public void toggleSounds() {

    }
    /**
     *
     * @return
     */
    private IdealGasMainPanel getIdealGasMainPanel() {
        return (IdealGasMainPanel)getPhetMainPanel();
    }

    protected JMenu createControlsMenu( PhetFrame phetFrame ) {
        return new IdealGasControlsMenu( phetFrame, this );
    }

    protected JMenu createTestMenu() {
        return new IdealGasTestMenu( this );
    }

    protected PhetAboutDialog getAboutDialog( PhetFrame phetFrame) {
        return new IdealGasAboutDialog( phetFrame );
    }

    protected Config getConfig() {
        return new IdealGasConfig();
    }

    //
    // Static fields and methods
    //
    public static void main( String[] args ) {

        IdealGasApplication application = new IdealGasApplication();
        application.start();
    }
}
