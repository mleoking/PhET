/**
 * Created by IntelliJ IDEA.
 * User: Another Guy
 * Date: Feb 18, 2003
 * Time: 8:46:30 AM
 * To change this template use Options | File Templates.
 */
package edu.colorado.phet.idealgas.graphics;

import edu.colorado.phet.controller.PhetApplication;
import edu.colorado.phet.idealgas.controller.IdealGasApplication;
import edu.colorado.phet.idealgas.controller.IdealGasConfig;
import edu.colorado.phet.graphics.MovableImageGraphic;
import edu.colorado.phet.graphics.util.ResourceLoader;

import java.awt.*;

public class IdealGasApparatusPanel2 extends IdealGasApparatusPanel {

//    IdealGasApplication application;

    public IdealGasApparatusPanel2( PhetApplication application ) {
        super( application,"Ideal Gas" );
//        this.application = (IdealGasApplication)application;

        // Set up the door for the box
        ResourceLoader loader = new ResourceLoader();
        Image doorImg = loader.loadImage( IdealGasConfig.DOOR_IMAGE_FILE ).getImage();
        doorGraphicImage = new MovableImageGraphic(
                doorImg,
                IdealGasConfig.X_BASE_OFFSET + 280, IdealGasConfig.Y_BASE_OFFSET + 227,
                IdealGasConfig.X_BASE_OFFSET + 150, IdealGasConfig.Y_BASE_OFFSET + 227,
                IdealGasConfig.X_BASE_OFFSET + 280, IdealGasConfig.Y_BASE_OFFSET + 227 );
        this.addGraphic( doorGraphicImage, -6 );

    }

    /**
     * Starts the application running for the specific apparatus panel
     */
    public void activate() {
        super.activate();
        if( getIdealGasApplication().getPhetMainPanel() != null ) {
            getIdealGasApplication().run();
        }
    }
}
