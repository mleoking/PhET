/**
 * Class: FissionListener
 * Package: edu.colorado.phet.nuclearphysics.model
 * Author: Another Guy
 * Date: Mar 19, 2004
 */
package edu.colorado.phet.nuclearphysics.model;

public interface FissionListener {
    void fission( FissionProducts products );
}
