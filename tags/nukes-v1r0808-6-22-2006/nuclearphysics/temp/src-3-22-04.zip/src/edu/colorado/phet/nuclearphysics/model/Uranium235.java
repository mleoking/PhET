/**
 * Class: Uranium235
 * Package: edu.colorado.phet.nuclearphysics.model
 * Author: Another Guy
 * Date: Feb 26, 2004
 */
package edu.colorado.phet.nuclearphysics.model;

import edu.colorado.phet.common.math.Vector2D;
import edu.colorado.phet.nuclearphysics.Config;

import java.awt.geom.Point2D;
import java.util.ArrayList;

public class Uranium235 extends Nucleus {

    private ArrayList decayListeners = new ArrayList();
    private AlphaParticle[] alphaParticles = new AlphaParticle[4];

    public Uranium235( Point2D.Double position ) {
        super( position, 145, 92 /*, potentialProfile */ );
        for( int i = 0; i < alphaParticles.length; i++ ) {
            alphaParticles[i] = new AlphaParticle( position,
                                                   getPotentialProfile().getAlphaDecayX() * Config.AlphaLocationUncertaintySigmaFactor );
            alphaParticles[i].setNucleus( this );
        }
    }

    public AlphaParticle[] getAlphaParticles() {
        return alphaParticles;
    }

    public void addDecayListener( DecayListener listener ) {
        this.decayListeners.add( listener );
    }

    public void stepInTime( double dt ) {

        // See if any of the alpha particles has escaped, and initiate alpha decay if it has
        for( int j = 0; j < alphaParticles.length; j++ ) {
            AlphaParticle alphaParticle = alphaParticles[j];
            if( alphaParticle.getLocation().distanceSq( this.getLocation() ) - alphaParticle.getRadius()
                > getPotentialProfile().getAlphaDecayX() * getPotentialProfile().getAlphaDecayX() ) {

//                try {
//                    Thread.sleep( 1000 );
//                }
//                catch( InterruptedException e ) {
//                    e.printStackTrace();
//                }

                AlphaDecayProducts decayProducts = new AlphaDecayProducts( this, alphaParticle );
                for( int i = 0; i < decayListeners.size(); i++ ) {
                    DecayListener decayListener = (DecayListener)decayListeners.get( i );
                    decayListener.alphaDecay( decayProducts );
                }
                return;
            }
        }
        super.stepInTime( dt );
    }
}
