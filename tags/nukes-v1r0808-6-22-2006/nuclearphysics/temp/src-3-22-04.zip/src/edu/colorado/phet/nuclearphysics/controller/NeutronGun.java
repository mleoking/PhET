/**
 * Class: NeutronGun
 * Package: edu.colorado.phet.nuclearphysics.controller
 * Author: Another Guy
 * Date: Mar 17, 2004
 */
package edu.colorado.phet.nuclearphysics.controller;

public interface NeutronGun {
    public void fireNeutron();
}
