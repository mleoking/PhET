/**
 * Class: ControlPane
 * Package: edu.colorado.phet.coreadditions
 * Author: Another Guy
 * Date: Jul 18, 2003
 */
package edu.colorado.phet.coreadditions;

import javax.swing.*;
import java.awt.*;

public class ControlPane extends JPanel {

    public ControlPane() {
//        setBackground( s_backgroundColor );
    }

    public static Color s_backgroundColor = new Color( 100, 100, 200 );
}
