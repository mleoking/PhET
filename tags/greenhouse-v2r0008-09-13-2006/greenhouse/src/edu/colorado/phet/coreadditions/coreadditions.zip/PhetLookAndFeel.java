/**
 * Class: PhetLookAndFeel
 * Package: edu.colorado.phet.coreadditions
 * Author: Another Guy
 * Date: Aug 5, 2003
 */
package edu.colorado.phet.coreadditions;

import java.awt.*;

public interface PhetLookAndFeel {
    public Image getSmallIconImage();
}
