/** Sam Reid*/
package edu.colorado.phet.cck3;

import edu.colorado.phet.common.math.AbstractVector2D;
import edu.colorado.phet.common.util.SimpleObservable;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 1:32:58 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class Branch extends SimpleObservable {
    private Junction startJunction;
    private Junction endJunction;
    double thickness;

    public Branch( Junction startJunction, Junction endJunction ) {
        this.startJunction = startJunction;
        this.endJunction = endJunction;
    }

    public AbstractVector2D getDirectionVector() {
        return endJunction.getPosition().getSubtractedInstance( startJunction.getPosition() );
    }

    public double getX1() {
        return startJunction.getX();
    }

    public double getY1() {
        return startJunction.getY();
    }

    public double getX2() {
        return endJunction.getX();
    }

    public double getY2() {
        return endJunction.getY();
    }

    public void translate( double dx, double dy ) {
        startJunction.translate( dx, dy );
        endJunction.translate( dx, dy );
        notifyObservers();
    }

    public Junction getStartJunction() {
        return startJunction;
    }

    public Junction getEndJunction() {
        return endJunction;
    }

    public boolean hasJunction( Junction junction ) {
        return endJunction == junction || startJunction == junction;
    }

    public Junction opposite( Junction a ) {
        if (startJunction==a){
            return endJunction;
        }
        else if (endJunction==a){
            return startJunction;
        }
        else throw new RuntimeException("No such junction: "+a);
    }

    public void setStartJunction( Junction newJunction ) {
        this.startJunction=newJunction;
    }

    public void setEndJunction( Junction newJunction ) {
        this.endJunction=newJunction;
    }


}
