/** Sam Reid*/
package edu.colorado.phet.cck3;

import java.util.ArrayList;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 1:31:24 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class Circuit {
    ArrayList branches = new ArrayList();
    ArrayList junctions = new ArrayList();
    ArrayList listeners=new ArrayList( );
    public Circuit() {
    }
    public void addCircuitListener(CircuitListener listener){
        listeners.add(listener );
    }
    public Branch createBranch( double x1, double y1, double x2, double y2 ) {
        Junction startJunction = new Junction( x1, y1 );
        Junction endJunction = new Junction( x2, y2 );
        addJunction( startJunction );
        addJunction( endJunction );
        Branch branch = new Branch( startJunction, endJunction );
        branches.add( branch );
        return branch;
    }

    private void addJunction( Junction startJunction ) {
        junctions.add( startJunction );
    }

    public void updateNeighbors( Junction junction ) {
        for( int i = 0; i < branches.size(); i++ ) {
            Branch branch = (Branch)branches.get( i );
            if( branch.hasJunction( junction ) ) {
                branch.notifyObservers();
            }
        }
    }

    public int numJunctions() {
        return junctions.size();
    }

    public Junction junctionAt( int i ) {
        return (Junction)junctions.get( i );
    }

    public boolean hasBranch( Junction a, Junction b ) {
        for( int i = 0; i < branches.size(); i++ ) {
            Branch branch = (Branch)branches.get( i );
            if (branch.hasJunction( a)&&branch.hasJunction( b) ){
                return true;
            }
        }
        return false;
    }

    public Junction[] getNeighbors( Junction a ) {
        ArrayList n=new ArrayList( );
        for( int i = 0; i < branches.size(); i++ ) {
            Branch branch = (Branch)branches.get( i );
            if (branch.hasJunction( a ) ){
                n.add(branch.opposite(a));
            }
        }
        return (Junction[])n.toArray( new Junction[0]);
    }

//    public void removeJunction( Junction junction ) {
//        junctions.remove( junction );
//    }

    public void replaceJunction( Junction old, Junction newJunction ) {
        junctions.remove( old );

        for( int i = 0; i < branches.size(); i++ ) {
            Branch branch = (Branch)branches.get( i );
            if (branch.getStartJunction()==old){
                branch.setStartJunction(newJunction);
            }
            if (branch.getEndJunction()==old){
                branch.setEndJunction(newJunction);
            }
        }
        fireJunctionRemoved(old);
    }

    private void fireJunctionRemoved( Junction junction ) {
        for( int i = 0; i < listeners.size(); i++ ) {
            CircuitListener circuitListener = (CircuitListener)listeners.get( i );
            circuitListener.junctionRemoved( junction );
        }
    }

}
