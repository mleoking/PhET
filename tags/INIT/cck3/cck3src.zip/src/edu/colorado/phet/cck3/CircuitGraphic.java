/** Sam Reid*/
package edu.colorado.phet.cck3;

import edu.colorado.phet.common.view.ApparatusPanel;
import edu.colorado.phet.common.view.CompositeInteractiveGraphic;
import edu.colorado.phet.common.view.graphics.transforms.ModelViewTransform2D;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 10:17:59 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class CircuitGraphic extends CompositeInteractiveGraphic {
//    ArrayList branchGraphics = new ArrayList();
//    ArrayList junctionGraphics = new ArrayList();
    CompositeInteractiveGraphic branches = new CompositeInteractiveGraphic();
    CompositeInteractiveGraphic junctions = new CompositeInteractiveGraphic();
    private Circuit circuit;
    private ModelViewTransform2D transform;
    private ApparatusPanel apparatusPanel;

    public CircuitGraphic( Circuit circuit, ModelViewTransform2D transform, ApparatusPanel apparatusPanel ) {
        this.circuit = circuit;
        this.transform = transform;
        this.apparatusPanel = apparatusPanel;
        addGraphic( branches );
        addGraphic( junctions );
    }

    public void addGraphic( Branch branch ) {
        TotalBranchGraphic totalBranchGraphic = new TotalBranchGraphic( circuit, branch, apparatusPanel, transform );
        branches.addGraphic( totalBranchGraphic.getInteractiveBranchGraphic() );
        junctions.addGraphic( totalBranchGraphic.getInteractiveJunctionGraphic1() );
        junctions.addGraphic( totalBranchGraphic.getInteractiveJunctionGraphic2() );
    }

}
