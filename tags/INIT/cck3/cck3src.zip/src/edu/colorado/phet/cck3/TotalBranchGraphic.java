/** Sam Reid*/
package edu.colorado.phet.cck3;

import edu.colorado.phet.common.view.ApparatusPanel;
import edu.colorado.phet.common.view.CompositeInteractiveGraphic;
import edu.colorado.phet.common.view.graphics.transforms.ModelViewTransform2D;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 9:05:19 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class TotalBranchGraphic extends CompositeInteractiveGraphic {
    double wireThickness = .4;
    double junctionRadius = .4;
    private Circuit circuit;
    private InteractiveBranchGraphic interactiveBranchGraphic;
    private InteractiveJunctionGraphic interactiveJunctionGraphic1;
    private InteractiveJunctionGraphic interactiveJunctionGraphic2;

    public TotalBranchGraphic( Circuit circuit, final Branch branch, ApparatusPanel apparatusPanel, final ModelViewTransform2D transform ) {
        this.circuit = circuit;

        BranchGraphic bg = new BranchGraphic( branch, apparatusPanel, wireThickness, transform );
        interactiveBranchGraphic = new InteractiveBranchGraphic( bg, transform );

        JunctionGraphic jg = new JunctionGraphic( apparatusPanel, branch.getStartJunction(), transform, junctionRadius );
        JunctionGraphic jg2 = new JunctionGraphic( apparatusPanel, branch.getEndJunction(), transform, junctionRadius );
        interactiveJunctionGraphic1 = new InteractiveJunctionGraphic( circuit, jg, transform );
        interactiveJunctionGraphic2 = new InteractiveJunctionGraphic( circuit, jg2, transform );
        addGraphic( interactiveBranchGraphic );
        addGraphic( interactiveJunctionGraphic1 );
        addGraphic( interactiveJunctionGraphic2 );
    }

    public InteractiveBranchGraphic getInteractiveBranchGraphic() {
        return interactiveBranchGraphic;
    }

    public InteractiveJunctionGraphic getInteractiveJunctionGraphic1() {
        return interactiveJunctionGraphic1;
    }

    public InteractiveJunctionGraphic getInteractiveJunctionGraphic2() {
        return interactiveJunctionGraphic2;
    }
}
