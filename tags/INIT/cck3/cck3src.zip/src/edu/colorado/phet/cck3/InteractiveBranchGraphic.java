/** Sam Reid*/
package edu.colorado.phet.cck3;

import edu.colorado.phet.common.view.graphics.DefaultInteractiveGraphic;
import edu.colorado.phet.common.view.graphics.mousecontrols.Translatable;
import edu.colorado.phet.common.view.graphics.transforms.ModelViewTransform2D;

import java.awt.geom.Point2D;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 9:29:56 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class InteractiveBranchGraphic extends DefaultInteractiveGraphic {
    public InteractiveBranchGraphic( final BranchGraphic boundedGraphic, final ModelViewTransform2D transform ) {
        super( boundedGraphic );
        addCursorHandBehavior();
        addTranslationBehavior( new Translatable() {
            public void translate( double dx, double dy ) {
                Point2D.Double pt = transform.viewToModelDifferential( (int)dx, (int)dy );
                boundedGraphic.getBranch().translate( pt.x, pt.y );
            }
        } );
    }

}
