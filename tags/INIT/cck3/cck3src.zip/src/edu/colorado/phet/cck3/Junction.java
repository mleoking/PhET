/** Sam Reid*/
package edu.colorado.phet.cck3;

import edu.colorado.phet.common.math.ImmutableVector2D;
import edu.colorado.phet.common.util.SimpleObservable;

import java.awt.geom.Point2D;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 1:37:51 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class Junction extends SimpleObservable {
    private double x;
    private double y;

    public Junction( double x, double y ) {
        this.x = x;
        this.y = y;
    }

    public ImmutableVector2D.Double getPosition() {
        return new ImmutableVector2D.Double( x, y );
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void translate( double dx, double dy ) {
        x += dx;
        y += dy;
        notifyObservers();
    }

    public void setPosition( double x, double y ) {
        this.x = x;
        this.y = y;
        notifyObservers();
    }

    public double getDistance( Junction dragging ) {
        return getPosition().getSubtractedInstance( dragging.getPosition() ).getMagnitude();
    }

    public double getDistance( Point2D.Double pt ) {
        return pt.distance( getX(), getY() );
    }
}
