/** Sam Reid*/
package edu.colorado.phet.cck3.common;

import edu.colorado.phet.common.math.AbstractVector2D;
import edu.colorado.phet.common.math.ImmutableVector2D;
import edu.colorado.phet.common.view.util.DoubleGeneralPath;

import java.awt.*;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 1:48:42 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class LineSegment {
    public static Shape getSegment( double x1, double y1, double x2, double y2, double thickness ) {
//        GeneralPath path=new GeneralPath( );
////        path.moveTo( (float)x1,(float)y1);
        ImmutableVector2D.Double vec = new ImmutableVector2D.Double( x2 - x1, y2 - y1 );
        AbstractVector2D norm = vec.getNormalVector().getInstanceOfMagnitude( thickness / 2 );
//        path.moveTo( (float)( x1+norm.getX() ),(float)(y1+norm.getY()));
        DoubleGeneralPath doublePath = new DoubleGeneralPath( x1 + norm.getX(), y1 + norm.getY() );

        doublePath.lineToRelative( vec.getX(), vec.getY() );
        AbstractVector2D n2 = norm.getScaledInstance( -2 );
        doublePath.lineToRelative( n2.getX(), n2.getY() );
        AbstractVector2D rev = vec.getScaledInstance( -1 );
        doublePath.lineToRelative( rev.getX(), rev.getY() );
        doublePath.lineTo( x1 + norm.getX(), y1 + norm.getY() );
        return doublePath.getGeneralPath();
    }
}
