/** Sam Reid*/
package edu.colorado.phet.cck3;

import edu.colorado.phet.common.application.ApplicationModel;
import edu.colorado.phet.common.application.Module;
import edu.colorado.phet.common.application.PhetApplication;
import edu.colorado.phet.common.model.BaseModel;
import edu.colorado.phet.common.model.clock.AbstractClock;
import edu.colorado.phet.common.model.clock.ClockTickListener;
import edu.colorado.phet.common.model.clock.SwingTimerClock;
import edu.colorado.phet.common.view.ApparatusPanel;
import edu.colorado.phet.common.view.BasicGraphicsSetup;
import edu.colorado.phet.common.view.graphics.Graphic;
import edu.colorado.phet.common.view.graphics.transforms.ModelViewTransform2D;
import edu.colorado.phet.common.view.util.framesetup.FrameCenterer;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.Rectangle2D;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 1:27:42 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class CCK3Module extends Module {
    Circuit circuit;
    CircuitGraphic circuitGraphic;
    boolean inited = false;
    private ModelViewTransform2D transform;
    private static final double JR = .9;

    public CCK3Module() {
        super( "cck-iii" );
        setApparatusPanel( new ApparatusPanel() );
        getApparatusPanel().addGraphicsSetup( new BasicGraphicsSetup() );
        setModel( new BaseModel() );
        circuit = new Circuit();
        getApparatusPanel().addComponentListener( new ComponentAdapter() {
            public void componentResized( ComponentEvent e ) {
                relayout();
            }

            public void componentShown( ComponentEvent e ) {
                relayout();
            }
        } );
    }

    private void relayout() {
        if( !inited ) {
            doinit();
            inited = true;
        }
        Rectangle viewBounds = getApparatusPanel().getBounds();
        transform.setViewBounds( viewBounds );
        getApparatusPanel().repaint();
    }

    private void doinit() {
        Rectangle2D.Double modelBounds = new Rectangle2D.Double( 0, 0, 10, 10 );
        Rectangle viewBounds = getApparatusPanel().getBounds();
        transform = new ModelViewTransform2D( modelBounds, viewBounds );

        circuitGraphic = new CircuitGraphic( circuit, transform, getApparatusPanel() );
        Branch branch = circuit.createBranch( 4, 3, 7, 3 );
        circuitGraphic.addGraphic( branch);
//        TotalBranchGraphic totalBranchGraphic = new TotalBranchGraphic( circuit, branch, getApparatusPanel(), transform );
//        circuitGraphic.addGraphic( totalBranchGraphic, 1 );
//
//        Branch b2 = circuit.createBranch( 4, 7, 7, 7 );
//        TotalBranchGraphic g2 = new TotalBranchGraphic( circuit, b2, getApparatusPanel(), transform );
//        circuitGraphic.addGraphic( g2, 1 );

        addGraphic( circuitGraphic, 2 );
    }

    static int r = 250;
    static int g = 250;
    static int b = 250;

    public static void main( String[] args ) {
        SwingTimerClock clock = new SwingTimerClock( 1, 30, true );

        Graphic colorG = new Graphic() {
            public void paint( Graphics2D gr ) {
                gr.setColor( new Color( r, g, b ) );
                gr.fillRect( 0, 0, 600, 600 );
            }
        };
        clock.addClockTickListener( new ClockTickListener() {
            public void clockTicked( AbstractClock c, double dt ) {
                r = ( r + 2 ) % 255;
                g = ( g + 3 ) % 255;
                b = ( b + 4 ) % 255;
            }
        } );

        CCK3Module cck = new CCK3Module();
        cck.addGraphic( colorG, -1 );

        ApplicationModel model = new ApplicationModel( "CCK3", "aoue", "aoeu", new FrameCenterer( 300, 300 ), cck, clock );
        PhetApplication app = new PhetApplication( model );
        app.startApplication();
    }
}
