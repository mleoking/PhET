/** Sam Reid*/
package edu.colorado.phet.cck3;

import edu.colorado.phet.common.view.graphics.DefaultInteractiveGraphic;
import edu.colorado.phet.common.view.graphics.transforms.ModelViewTransform2D;

import javax.swing.event.MouseInputAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

/**
 * User: Sam Reid
 * Date: May 24, 2004
 * Time: 9:10:07 AM
 * Copyright (c) May 24, 2004 by Sam Reid
 */
public class InteractiveJunctionGraphic extends DefaultInteractiveGraphic {
    private Circuit circuit;
    private JunctionGraphic jg;
    private ModelViewTransform2D transform;
    private double threshold = 1;
    private Junction mytarget;

    public InteractiveJunctionGraphic( final Circuit circuit, final JunctionGraphic jg, final ModelViewTransform2D transform ) {
        super( jg );
        this.circuit = circuit;
        this.jg = jg;
        this.transform = transform;
        addCursorHandBehavior();

        MouseInputAdapter input = new MouseInputAdapter() {
            // implements java.awt.event.MouseMotionListener
            public void mouseDragged( MouseEvent e ) {
                Point2D.Double pt = transform.viewToModel( e.getX(), e.getY() );

                //find a potential match.
                Junction target = getPotentialMatch( jg.getJunction() );
                if( target == null || target.getDistance( pt ) > threshold ) {
                    jg.getJunction().setPosition( pt.getX(), pt.getY() );
                    circuit.updateNeighbors( jg.getJunction() );
                    mytarget = null;
                }
                else {
                    jg.getJunction().setPosition( target.getX(), target.getY() );
                    circuit.updateNeighbors( jg.getJunction() );
                    mytarget = target;
                }
            }

            // implements java.awt.event.MouseListener
            public void mousePressed( MouseEvent e ) {
            }

            // implements java.awt.event.MouseListener
            public void mouseReleased( MouseEvent e ) {
                if( mytarget != null ) {
                    //make a connection.
                    //This means killing one junction and its corresponding graphic.
//                    circuit.removeJunction( mytarget );
                    circuit.replaceJunction(mytarget,jg.getJunction());
                }
            }
        };
        addMouseInputListener( input );
    }

    private Junction getPotentialMatch( Junction dragging ) {
        Junction closestJunction = null;
        double closestValue = Double.POSITIVE_INFINITY;

        for( int i = 0; i < circuit.numJunctions(); i++ ) {
            Junction j = circuit.junctionAt( i );
            double dist = j.getDistance( dragging );
            if( j != dragging && !circuit.hasBranch( dragging, j ) && !wouldCauseOverlap( dragging, j ) ) {
                if( closestJunction == null || dist < closestValue ) {
                    closestValue = dist;
                    closestJunction = j;
                }
            }
        }
        return closestJunction;
    }

    private boolean wouldCauseOverlap( Junction a, Junction b ) {
        Junction[] neighborsOfA = circuit.getNeighbors( a );
        Junction[] neighborsOfB = circuit.getNeighbors( b );
        for( int i = 0; i < neighborsOfA.length; i++ ) {
            Junction junction = neighborsOfA[i];
            for( int j = 0; j < neighborsOfB.length; j++ ) {
                Junction junction1 = neighborsOfB[j];
                if( junction == junction1 ) {
                    return true;
                }
            }
        }
        return false;
    }
}
