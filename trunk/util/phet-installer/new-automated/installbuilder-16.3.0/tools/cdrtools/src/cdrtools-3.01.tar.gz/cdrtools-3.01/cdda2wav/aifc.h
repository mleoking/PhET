/* @(#)aifc.h	1.2 99/12/19 Copyright 1998,1999 Heiko Eissfeldt */
extern struct soundfile aifcsound;
