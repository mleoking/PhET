/* @(#)version.h	1.79 14/09/30 Copyright 2007-2014 J. Schilling */

/*
 * The version for cdrtools programs
 */
#define	VERSION	"3.01a25"
