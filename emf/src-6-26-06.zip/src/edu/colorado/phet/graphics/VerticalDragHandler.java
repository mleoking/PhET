/**
 * Class: VerticalDragHandler
 * Package: edu.colorado.phet.graphics
 * Author: Another Guy
 * Date: May 28, 2003
 */
package edu.colorado.phet.graphics;



import edu.colorado.phet.common.view.graphics.DragHandler;

import java.awt.*;

public class VerticalDragHandler {

    private DragHandler internalDragHandler;
    private int x;

    public VerticalDragHandler( Point point, Point point1 ) {
        internalDragHandler = new DragHandler( point, point1 );
        x = point1.x;
    }

    public Point getNewLocation( Point mousePosition ) {
        Point newPoint = internalDragHandler.getNewLocation( mousePosition );
        newPoint.x = this.x;
        return newPoint;
    }
}
