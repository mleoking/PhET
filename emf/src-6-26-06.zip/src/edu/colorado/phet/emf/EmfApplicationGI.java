/**
 * Class: EmfApplicationGI
 * Package: edu.colorado.phet.emf
 * Author: Another Guy
 * Date: Jun 20, 2003
 */
package edu.colorado.phet.emf;

import edu.colorado.phet.common.application.Module;
import edu.colorado.phet.common.application.PhetApplication;
import edu.colorado.phet.common.view.ApplicationDescriptor;
import edu.colorado.phet.guidedinquiry.controller.command.LaunchGuidedInquiryCmd;
import edu.colorado.phet.guidedinquiry.model.GILoader;
import edu.colorado.phet.guidedinquiry.model.GuidedInquiry;

import java.net.URL;
import java.net.MalformedURLException;

public class EmfApplicationGI extends EmfApplication {

    public static void main( String[] args ) {



        Module antennaModule = new AntennaModule();
        ApplicationDescriptor appDescriptor = new ApplicationDescriptor(
                "Electro-magnetic Fields", "yada-yada", ".01",
                                                           1024, 768 );
//        PhetApplication application = new PhetApplication( appDescriptor, antennaModule );
        PhetApplication application = new PhetApplication( appDescriptor,
                                                           new Module[] { antennaModule,
                                                                          new ManualControlModule() });
        application.startApplication( antennaModule );

        String giUrl = null;
        giUrl = args[0];
        System.out.println( giUrl );
        System.out.println( giUrl );
        GILoader giLoader = new GILoader();
        GuidedInquiry gi = giLoader.loadGI( giUrl );
        LaunchGuidedInquiryCmd lgiCmd = new LaunchGuidedInquiryCmd( application, gi );
        lgiCmd.doIt();

    }

}
