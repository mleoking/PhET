/**
 * Class: EmfSensingElectron
 * Package: edu.colorado.phet.emf.model
 * Author: Another Guy
 * Date: May 29, 2003
 */
package edu.colorado.phet.emf.model;

import edu.colorado.phet.common.math.Vector2D;
import edu.colorado.phet.emf.model.movement.ManualMovement;

import java.awt.geom.Point2D;

public class EmfSensingElectron extends Electron {
    private Point2D location;
    RetardedFieldElement retardedFieldElement;
    private Electron sourceElectron;
    private Point2D prevPosition = new Point2D.Double();

    public EmfSensingElectron( EmfModel model, Point2D.Double location, Electron sourceElectron ) {
        super( model, location );
        this.location = location;
        this.sourceElectron = sourceElectron;
        retardedFieldElement = new RetardedFieldElement( location, sourceElectron );
        this.setMovementStrategy( new ManualMovement() );
    }

    public synchronized void stepInTime( double dt ) {
        super.stepInTime( dt );
        Vector2D v = this.getVelocity();
        if( sourceElectron.isFieldOff() ) {
            v.setX( 0 );
            v.setY( 0 );
        }
        else {

            // The field strength is a force on the electron, so we must compute an
            // acceleration
            Vector2D fieldStrength = sourceElectron.getFieldAtLocation( location );
            Vector2D a = fieldStrength;
            v.setY( v.getY() + a.getY() * (float)dt / 1000 );

            double x = this.getCurrentPosition().getX();
            double y = this.getCurrentPosition().getY();

            location = this.getCurrentPosition();
            x += v.getX() * dt;
            y += v.getY() * dt;
            location.setLocation( x, y );
            this.setCurrentPosition( location );
        }
        updateObservers();
    }
}
