/**
 * Class: Electron
 * Package: edu.colorado.phet.waves.model
 * Author: Another Guy
 * Date: May 23, 2003
 */
package edu.colorado.phet.emf.model;

import edu.colorado.phet.common.math.Vector2D;
import edu.colorado.phet.common.model.ModelElement;
import edu.colorado.phet.emf.EmfApplication;
import edu.colorado.phet.emf.model.movement.ManualMovement;
import edu.colorado.phet.emf.model.movement.MovementType;
import edu.colorado.phet.emf.model.movement.SinusoidalMovement;

import java.awt.*;
import java.awt.geom.Point2D;

public class Electron extends ModelElement {

    private EmfModel model;
    private Point2D startPosition;
    private Point2D prevPosition = new Point2D.Double();
    private Point2D currentPosition = new Point2D.Double();
    private Vector2D velocity = new Vector2D();
    private MovementType movementStrategy;
    private double runningTime;

    // Number of time steps between emitting field elements. This
    // provides and animated look to the visualization.
    // TODO: this mechanism should be implemented in the view, not here
    private int steps = 0;

    // The position history of the electron
    private Point2D[] positionHistory = new Point2D.Float[s_retardedFieldLength];
    // The acceleration history of the electron
    private Vector2D[] accelerationHistory = new Vector2D[s_retardedFieldLength];
    // The history of the maximum acceleration the electron courld have had at
    // a point in time. This is needed so viewers can properly scale the actual
    // accelerations
    private Vector2D[] maxAccelerationHistory = new Vector2D[s_retardedFieldLength];
    private boolean changeFreq;
    private float newFreq;
    private boolean changeAmplitude;
    private float newAmplitude;


    public Electron( EmfModel model, Point2D.Double startPosition ) {
        this.model = model;
        this.startPosition = new Point2D.Double( startPosition.getX(), startPosition.getY() );
        this.currentPosition = new Point2D.Double( startPosition.getX(), startPosition.getY() );
        for( int i = 0; i < s_retardedFieldLength; i++ ) {
            positionHistory[i] = new Point2D.Float( Float.NaN, Float.NaN );
            accelerationHistory[i] = new Vector2D();
            maxAccelerationHistory[i] = new Vector2D();
        }
    }

    public Point2D getCurrentPosition() {
        return currentPosition;
    }

    public void setCurrentPosition( Point2D newPosition ) {
        currentPosition.setLocation( newPosition );
    }

    public void setMovementStrategy( MovementType movementStrategy ) {
        this.movementStrategy = movementStrategy;
    }

    public synchronized void stepInTime( double dt ) {
        prevPosition.setLocation( currentPosition );
        movementStrategy.stepInTime( this, dt );
        velocity = movementStrategy.getVelocity( this );
        runningTime += dt;
        recordPosition( currentPosition );

        // If we have a frequency change pending, determine if this is the right time to
        // make it
        if( changeFreq && movementStrategy instanceof SinusoidalMovement ) {
            if( ( prevPosition.getY() - startPosition.getY() ) * ( currentPosition.getY() - startPosition.getY() ) <= 0 ) {
                SinusoidalMovement sm = (SinusoidalMovement)movementStrategy;
                sm.setFrequency( newFreq );
                changeFreq = false;
            }
        }

        // If we have an amplitude change pending, determine if this is the right time to
        // make it
        if( changeAmplitude && movementStrategy instanceof SinusoidalMovement ) {
            if( ( prevPosition.getY() - startPosition.getY() ) * ( currentPosition.getY() - startPosition.getY() ) <= 0 ) {
                SinusoidalMovement sm = (SinusoidalMovement)movementStrategy;
                sm.setAmplitude( newAmplitude );
                changeAmplitude = false;
            }
        }
        updateObservers();
    }

    /**
     *
     */
    public synchronized void moveToNewPosition( Point newLocation ) {
        if( movementStrategy instanceof ManualMovement ) {
            ( (ManualMovement)movementStrategy ).setPosition( newLocation );
        }
    }

    private void recordPosition( Point2D position ) {
        for( int i = s_retardedFieldLength - 1; i > s_stepSize - 1; i-- ) {
            positionHistory[i].setLocation( positionHistory[i - s_stepSize] );
            accelerationHistory[i].setX( accelerationHistory[i - s_stepSize].getX() );
            accelerationHistory[i].setY( accelerationHistory[i - s_stepSize].getY() );
            maxAccelerationHistory[i].setX( maxAccelerationHistory[i - s_stepSize].getX() );
            maxAccelerationHistory[i].setY( maxAccelerationHistory[i - s_stepSize].getY() );
        }

        for( int i = 0; i < s_stepSize; i++ ) {
            positionHistory[i].setLocation( position );
            accelerationHistory[i].setY( movementStrategy.getAcceleration( this ) * s_B );
            maxAccelerationHistory[i].setY( movementStrategy.getMaxAcceleration( this ) * s_B );
        }
    }

    /**
     * Vestigial
     */
//    private void emitFieldElements() {
//        double c = EmfApplication.s_speedOfLight;
//        steps = ( steps + 1 ) % 3;
//        if( steps == 0 ) {
//            for( double theta = 0; theta < Math.PI * 2; theta += Math.PI * 2 / 8 ) {
//                double vx = c * Math.cos( theta );
//                double vy = c * Math.sin( theta );
//                FieldElement fieldElement = new FieldElement( this.currentPosition,
//                                                              new Vector2D( (float)vx, (float)vy ) );
//                new AddFieldElementCmd( fieldElement ).doIt();
//            }
//        }
//    }

    public Vector2D getVelocity() {
        return this.velocity;
    }

//    public Vector2D getFieldAtTimeAgo( double sourceTime ) {
//        int historyIndex = (int)( EmfApplication.s_speedOfLight * sourceTime );
//        return retardedField[historyIndex];
//    }

    public Point2D getStartPosition() {
        return this.startPosition;
    }

    private Vector2D staticFieldStrength = new Vector2D();
    public Vector2D getInstantaneousStaticField( Point2D location ) {
        staticFieldStrength.setX( (float)( location.getX() - getCurrentPosition().getX() ) );
        staticFieldStrength.setY( (float)( location.getY() - getCurrentPosition().getY() ) );
        staticFieldStrength.normalize();

        double distanceFromSource = location.distance( this.getCurrentPosition() );
        staticFieldStrength.multiply( s_B / (float)( distanceFromSource * distanceFromSource ) );
        return staticFieldStrength;
    }

    private Vector2D dynamicFieldStrength = new Vector2D();
    private Vector2D getInstantaneousDynamicField( Point2D location ) {

        dynamicFieldStrength.setX( (float)( -( location.getY() - this.getStartPosition().getY() )));
        dynamicFieldStrength.setY( (float)(location.getX() - this.getStartPosition().getX() ));
        dynamicFieldStrength.normalize();

        // Hollywood here! This computes the field based on the origin of the
        // electron's motion, not its current position
        double distanceFromSource = location.distance( this.getStartPosition() );
//        double distanceFromSource = location.distance( this.getCurrentPosition() );

        float acceleration = this.getAccelerationAt( (int)distanceFromSource );
        dynamicFieldStrength.multiply( acceleration /** 0.01f * s_B */ / (float)(Math.pow( distanceFromSource, 0.5 ) ));
        float dubsonFactor = (float)( (location.getX() - this.getStartPosition().getX() ) / distanceFromSource );
        dynamicFieldStrength.multiply( dubsonFactor );

        return dynamicFieldStrength;
    }

    private Vector2D fieldStrength = new Vector2D();
    public Vector2D getFieldAtLocation( Point2D location ) {
        fieldStrength.setX( 0 );
        fieldStrength.setY( 0 );
        // TODO: rjl 6/26/03
        if( model.isStaticFieldEnabled() ) {
//        if( EmfModel.instance().isStaticFieldEnabled() ) {
            fieldStrength.add( getInstantaneousStaticField( location ) );
        }
        // TODO: rjl 6/26/03
        if( model.isDynamicFieldEnabled() ) {
//        if( EmfModel.instance().isDynamicFieldEnabled() ) {
            fieldStrength.add( getInstantaneousDynamicField( location ) );
        }

        return fieldStrength;
    }

    private float getAccelerationAt( int x ) {
        return accelerationHistory[ Math.min( x, accelerationHistory.length - 1 )].getY();
    }

    public float getMass() {
        //mr = m0 /sqrt(1 - v2/c2)
        float vMag = this.getVelocity().getLength();
        float denom = (float)Math.sqrt( 1 -( vMag * vMag ) / ( EmfApplication.s_speedOfLight * EmfApplication.s_speedOfLight ) );
        if( denom < 1) {
            System.out.println( denom );
        }
        float mr = s_restMass / denom;
        return mr;
    }

    public void setFrequency( float freq ) {
        if( this.movementStrategy instanceof SinusoidalMovement ) {
            changeFreq = true;
            newFreq = freq;
        }
    }


    public void setAmplitude( float amplitude ) {
        if( this.movementStrategy instanceof SinusoidalMovement ) {
            changeAmplitude = true;
            newAmplitude = amplitude;
        }
    }

    public Vector2D getMaxAccelerationAtLocations( Point2D.Double location ) {
        double distanceFromSource = location.distance( this.getStartPosition() );
        return this.maxAccelerationHistory[ (int)distanceFromSource ];
    }

    /**
     * Tells if all elements of the field history are zero
     * @return
     */
    public boolean isFieldOff() {
        boolean result = true;
        for( int i = 0; i < accelerationHistory.length && result == true ; i++ ) {
            Vector2D field = accelerationHistory[i];
            if( field.getX() != 0 || field.getY() != 0 ) {
                result = false;
            }
        }
        return result;
    }

    //
    // Static fields and methods
    //
    private static final int s_retardedFieldLength = 1000;
    private static final float s_B = 1000;
    private static final float s_restMass = 1;
    private static int s_stepSize = (int)( EmfApplication.s_speedOfLight );
//    private static int s_stepSize = (int)( EmfApplication.s_speedOfLight / 4 );

    public static float getRestMass() {
        return s_restMass;
    }
}
