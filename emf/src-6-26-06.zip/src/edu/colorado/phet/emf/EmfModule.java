/**
 * Class: EmfModule
 * Package: edu.colorado.phet.emf
 * Author: Another Guy
 * Date: Jun 25, 2003
 */
package edu.colorado.phet.emf;

import edu.colorado.phet.command.AddTransmittingElectronCmd;
import edu.colorado.phet.common.application.Module;
import edu.colorado.phet.common.application.PhetApplication;
import edu.colorado.phet.common.model.command.Command;
import edu.colorado.phet.emf.model.Electron;
import edu.colorado.phet.emf.model.EmfModel;
import edu.colorado.phet.emf.model.EmfSensingElectron;
import edu.colorado.phet.emf.view.AntennaPanel;
import edu.colorado.phet.emf.view.ElectronGraphic;
import edu.colorado.phet.emf.command.DynamicFieldIsEnabledCmd;

import java.awt.*;
import java.awt.geom.Point2D;

public abstract class EmfModule extends Module {

//    private Electron electron;

    public EmfModule( String name ) {
        super( name );

        super.setModel( s_emfModel );
//        super.setModel( new EmfModel() );

//        Point origin = new Point( 105, 300 );
//        electron = new Electron( (EmfModel)this.getModel(),
//                                 new Point2D.Double( origin.getX(), origin.getY() + 00 ) );
//        new AddTransmittingElectronCmd( (EmfModel)this.getModel(), electron ).doIt();
//        new DynamicFieldIsEnabledCmd( (EmfModel)getModel(), true ).doIt();

//        super.setModel( new EmfModel() );
//        super.setModel( EmfModel.instance() );
//        super.setControlPanel( new AntennaControlPanel( this ) );
        int fieldWidth = 1000;
        int fieldHeight = 700;

        super.setApparatusPanel( new AntennaPanel( (EmfModel)this.getModel(),
                                                   s_electron,
                                                   s_origin,
//                                                   origin,
                                                   fieldWidth,
                                                   fieldHeight
        ) );

        // Set up the electron graphic
        ElectronGraphic electronGraphic = new ElectronGraphic( s_electron );
//        ElectronGraphic electronGraphic = new ElectronGraphic( electron );
        s_electron.addObserver( electronGraphic );
//        electron.addObserver( electronGraphic );
        this.getApparatusPanel().addGraphic( electronGraphic, 5 );

        // Set up the receiving electron
//        Point2D.Double receivingElectronLoc = new Point2D.Double( origin.x + 650, electron.getStartPosition().getY() + 100 );
//        final EmfSensingElectron receivingElectron = new EmfSensingElectron(
//                (EmfModel)this.getModel(), receivingElectronLoc, electron );
//        getModel().execute( new Command() {
//            public void doIt() {
//                getModel().addModelElement( receivingElectron );
//            }
//        } );

        ElectronGraphic receivingElectronGraphic = new ElectronGraphic( s_receivingElectron );
//        ElectronGraphic receivingElectronGraphic = new ElectronGraphic( receivingElectron );
        s_receivingElectron.addObserver( receivingElectronGraphic );
//        receivingElectron.addObserver( receivingElectronGraphic );
        this.getApparatusPanel().addGraphic( receivingElectronGraphic, 5 );

    }
                                       /
    public void setAutoscaleEnabled( boolean enabled ) {
        ( (AntennaPanel)this.getApparatusPanel() ).setAutoscaleEnabled( enabled );
    }


    //
    public void activate( PhetApplication app ) {
    }

    public void deactivate( PhetApplication app ) {
    }

    //
    // Static fields and methods
    //
    private static EmfModel s_emfModel = new EmfModel();
    private static Point s_origin = new Point( 105, 300 );
    private static Electron s_electron = new Electron( s_emfModel,
                                                       new Point2D.Double( s_origin.getX(), s_origin.getY() + 00 ) );
    private static Point2D.Double s_receivingElectronLoc = new Point2D.Double( s_origin.x + 650, s_electron.getStartPosition().getY() + 100 );
    private static EmfSensingElectron s_receivingElectron = new EmfSensingElectron(
            s_emfModel, s_receivingElectronLoc, s_electron );

    static {
        s_emfModel.addModelElement( s_electron );
        s_emfModel.setDynamicFieldEnabled( true );
        s_emfModel.addModelElement( s_receivingElectron );
    }
}
