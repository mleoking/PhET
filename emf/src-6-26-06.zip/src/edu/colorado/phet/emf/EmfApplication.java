/**
 * Class: EmfApplication
 * Package: edu.colorado.phet.emf
 * Author: Another Guy
 * Date: May 23, 2003
 */
package edu.colorado.phet.emf;

import edu.colorado.phet.common.application.Module;
import edu.colorado.phet.common.application.PhetApplication;
import edu.colorado.phet.common.view.ApplicationDescriptor;

public class EmfApplication {

    //
    // Static fields and methods
    //
    public static double s_speedOfLight = 10;

    public static void main( String[] args ) {
        Module antennaModule = new AntennaModule();
        ApplicationDescriptor appDescriptor = new ApplicationDescriptor(
                "Electro-magnetic Fields", "yada-yada", ".01",
                                                           1024, 768 );
//        PhetApplication application = new PhetApplication( appDescriptor, antennaModule );
        PhetApplication application = new PhetApplication( appDescriptor,
                                                           new Module[] { antennaModule,
                                                                          new ManualControlModule() });
        application.startApplication( antennaModule );

    }
}
