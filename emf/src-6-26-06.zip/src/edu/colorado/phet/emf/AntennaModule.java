/**
 * Class: AntennaModule
 * Package: edu.colorado.phet.emf
 * Author: Another Guy
 * Date: Jun 12, 2003
 */
package edu.colorado.phet.emf;

import edu.colorado.phet.command.AddTransmittingElectronCmd;
import edu.colorado.phet.common.application.Module;
import edu.colorado.phet.common.application.PhetApplication;
import edu.colorado.phet.common.model.command.Command;
import edu.colorado.phet.emf.command.SetMovementCmd;
import edu.colorado.phet.emf.model.Electron;
import edu.colorado.phet.emf.model.EmfModel;
import edu.colorado.phet.emf.model.EmfSensingElectron;
import edu.colorado.phet.emf.model.movement.ManualMovement;
import edu.colorado.phet.emf.model.movement.SinusoidalMovement;
import edu.colorado.phet.emf.view.AntennaControlPanel;
import edu.colorado.phet.emf.view.AntennaPanel;
import edu.colorado.phet.emf.view.ElectronGraphic;

import java.awt.*;
import java.awt.geom.Point2D;

public class AntennaModule extends EmfModule {

    private SinusoidalMovement sinusoidalMovement = new SinusoidalMovement( 0.01f, 50 );
    private ManualMovement manualMovement = new ManualMovement();
//    private Electron electron;

    public AntennaModule() {
        super( "Antennas" );

//        Point origin = new Point( 105, 300 );
//
//        electron = new Electron( new Point2D.Double( origin.getX(), origin.getY() + 00 ) );
//        new AddTransmittingElectronCmd( electron ).doIt();
//
//        super.setModel( EmfModel.instance() );
//        super.setControlPanel( new AntennaControlPanel( this ) );
//        int fieldWidth = 1000;
//        int fieldHeight = 700;
//
//        super.setApparatusPanel( new AntennaPanel( electron,
//                                                   origin,
//                                                   fieldWidth,
//                                                   fieldHeight
//                                                   ) );
//
//        // Set up the electron graphic
//        ElectronGraphic electronGraphic = new ElectronGraphic( electron );
//        electron.addObserver( electronGraphic );
//        this.getApparatusPanel().addGraphic( electronGraphic, 5 );
//
//        // Set up the receiving electron
//        Point2D.Double receivingElectronLoc = new Point2D.Double( origin.x + 650, electron.getStartPosition().getY() + 100 );
//        final EmfSensingElectron receivingElectron = new EmfSensingElectron( receivingElectronLoc, electron );
//        getModel().execute( new Command() {
//            public void doIt() {
//                getModel().addModelElement( receivingElectron );
//            }
//        } );
//
//        ElectronGraphic receivingElectronGraphic = new ElectronGraphic( receivingElectron );
//        receivingElectron.addObserver( receivingElectronGraphic );
//        this.getApparatusPanel().addGraphic( receivingElectronGraphic, 5 );
//
//        setMovementSinusoidal();
    }


    public void activate( PhetApplication app ) {
        super.setControlPanel( new AntennaControlPanel( (EmfModel)this.getModel(),
                                                        this ) );

        this.getModel().execute( new SetMovementCmd( (EmfModel)this.getModel(),
                                                         sinusoidalMovement ));
    }

    public void deactivate( PhetApplication app ) {
    }

//    public void setMovementSinusoidal() {
//        this.getModel().execute( new SetMovementCmd( (EmfModel)this.getModel(),
//                                                         sinusoidalMovement ));
//    }

//    public void setMovementManual() {
////        this.getModel().execute( new SetMovementCmd( (EmfModel) this.getModel(),
////                                                     new RelativisticManualMovement( this.electron.getCurrentPosition() ) ));
//        this.getModel().execute( new SetMovementCmd( (EmfModel) this.getModel(),
//                                                     manualMovement ));
//    }

//    public void setAutoscaleEnabled( boolean enabled ) {
//        ((AntennaPanel)this.getApparatusPanel()).setAutoscaleEnabled( enabled );
//    }
}
