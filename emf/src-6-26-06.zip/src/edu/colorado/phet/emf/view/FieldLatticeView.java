/**
 * Class: FieldLatticeView
 * Package: edu.colorado.phet.emf.view
 * Author: Another Guy
 * Date: Jun 2, 2003
 */
package edu.colorado.phet.emf.view;

import edu.colorado.phet.common.math.Vector2D;
import edu.colorado.phet.common.view.graphics.ObservingGraphic;
import edu.colorado.phet.emf.model.Electron;
import edu.colorado.phet.emf.model.RetardedFieldElement;
import edu.colorado.phet.emf.view.graphics.splines.CubicSpline;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.Observable;

public class FieldLatticeView implements ObservingGraphic {

    private Point origin;
    private int latticeSpacingX;
    private int latticeSpacingY;
    private int numLatticePtsX;
    private int numLatticePtsY;
    private Vector2D[][] latticePts;
    private RetardedFieldElement[][] fieldElements;
    private int[] controlPts;
    private Electron sourceElectron;
    private boolean fieldCurvesEnabled;
    private CubicSpline spline = new CubicSpline();
    private boolean autoscaleEnabled = true;


    public FieldLatticeView( Electron sourceElectron, Point origin,
                             int width, int height,
                             int latticeSpacingX, int latticeSpacingY ) {
        this.origin = origin;
        this.latticeSpacingX = latticeSpacingX;
        this.latticeSpacingY = latticeSpacingY;
        numLatticePtsX = 1 + ( width - 1 ) / latticeSpacingX;
        numLatticePtsY = 1 + ( height - 1 ) / latticeSpacingY;
        latticePts = new Vector2D[numLatticePtsY][numLatticePtsX];
        fieldElements = new RetardedFieldElement[numLatticePtsY][numLatticePtsX];
        for( int i = 0; i < numLatticePtsY; i++ ) {
            for( int j = 0; j < numLatticePtsX; j++ ) {
                latticePts[i][j] = new Vector2D();
                fieldElements[i][j] = new RetardedFieldElement( new Point2D.Double( origin.getX() + j * latticeSpacingX,
                                                                                    origin.getY() + i * latticeSpacingY ),
                                                                sourceElectron );
            }
        }
        controlPts = new int[numLatticePtsX];
        this.sourceElectron = sourceElectron;
        sourceElectron.addObserver( this );
    }

    public void paint( Graphics2D g2 ) {
        for( int i = 0; i < numLatticePtsY; i++ ) {
            spline.reset();
            for( int j = 0; j < numLatticePtsX; j++ ) {
                int x = (int)origin.getX() + j * latticeSpacingX - 1;
                int y = (int)origin.getY() + i * latticeSpacingY - 1;
                g2.drawArc( x - 1, y - 1,
                            2, 2,
                            0, 360 );

                int fx = (int)latticePts[i][j].getX();
                int fy = (int)latticePts[i][j].getY();

                // This draws an arrow that pivots around the latice point
                drawArrow( g2, x - fx / 2, y - fy / 2, x + fx / 2, y + fy / 2 );

                controlPts[j] = y + fy / 2;
                spline.addPoint( x + fx / 2, y + fy / 2 );
            }

            if( fieldCurvesEnabled ) {
                Color oldColor = g2.getColor();
                g2.setColor( Color.BLUE );
                spline.paint( g2 );
                g2.setColor( oldColor );
            }
        }
    }

    private Polygon arrowHead = new Polygon();
    BasicStroke arrowStroke = new BasicStroke( 2 );

    private void drawArrow( Graphics2D g2, int x1, int y1, int x2, int y2 ) {
        if( x1 != x2 || y1 != y2 ) {

            // draw the line
//            Stroke oldStroke = g2.getStroke();
//            g2.setStroke( arrowStroke );
            g2.drawLine( x1, y1, x2, y2 );
//            g2.setStroke( oldStroke );

            // draw the arrowhead
            int w = 4; // width of arrowhead
            double l = Math.sqrt( ( x2 - x1 ) * ( x2 - x1 ) + ( y2 - y1 ) * ( y2 - y1 ) );
            double px = ( x2 - x1 ) / l;
            double py = ( y2 - y1 ) / l;
            arrowHead.reset();
            arrowHead.addPoint( (int)( x2 + w * px ), (int)( y2 + w * py ) );
            arrowHead.addPoint( (int)( x2 - ( w / 2 ) * py ), (int)( y2 - ( w / 2 ) * px ) );
            arrowHead.addPoint( (int)( x2 + ( w / 2 ) * py ), (int)( y2 + ( w / 2 ) * px ) );
            g2.drawPolygon( arrowHead );
            g2.fillPolygon( arrowHead );
        }
    }

    /**
     * Get the strength of the field at each of the lattice points
     */
    private Point2D.Double latticePtLocation = new Point2D.Double();

    public void update( Observable o, Object arg ) {
        if( o instanceof Electron ) {
            Electron electron = (Electron)o;
            for( int i = 0; i < numLatticePtsY; i++ ) {
                for( int j = 0; j < numLatticePtsX; j++ ) {
                    latticePtLocation.x = j * latticeSpacingX + origin.getX();
                    latticePtLocation.y = i * latticeSpacingY + origin.getY();

                    // Don't display field lines close to the electron
                    if( Math.abs( electron.getCurrentPosition().getX() - latticePtLocation.x )
                            > latticeSpacingX * 2
                            || Math.abs( electron.getCurrentPosition().getY() - latticePtLocation.y )
                            > latticeSpacingY * 2 ) {

                        Vector2D fs = sourceElectron.getFieldAtLocation( latticePtLocation );
                        latticePts[i][j].setX( fs.getX() );
                        latticePts[i][j].setY( fs.getY() );
                        if( autoscaleEnabled ) {
                            Vector2D fMax = sourceElectron.getMaxAccelerationAtLocations( latticePtLocation );
                            float scaleFactor = Math.abs( fMax.getY() != 0 ? latticeSpacingY / fMax.getY() : 1 );
                            scaleFactor /= 10;
                            latticePts[i][j].setX( fs.getX() * scaleFactor );
                            latticePts[i][j].setY( fs.getY() * scaleFactor );
                        }
                    }
                    else {
                        latticePts[i][j].setX( 0 );
                        latticePts[i][j].setY( 0 );
                    }
                }
            }
        }
    }

    public void setFieldCurvesEnabled( boolean enabled ) {
        this.fieldCurvesEnabled = enabled;
    }

    public void setAutoscaleEnabled( boolean enabled ) {
        this.autoscaleEnabled = enabled;
    }
}
