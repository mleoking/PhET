/**
 * Class: AntennaPanel
 * Package: edu.colorado.phet.waves.view
 * Author: Another Guy
 * Date: May 23, 2003
 */
package edu.colorado.phet.emf.view;

import edu.colorado.phet.common.view.ApparatusPanel;
import edu.colorado.phet.common.view.graphics.StaticImageGraphic;
import edu.colorado.phet.emf.model.Electron;
import edu.colorado.phet.emf.model.EmfModel;

import java.awt.*;

public class AntennaPanel extends ApparatusPanel {
    private FieldLatticeView fieldLatticeView;

    public AntennaPanel( EmfModel model, Electron electron, Point origin, int fieldWidth, int fieldHeight ) {

        AntennaPanel.setInstance( this );
        int latticeSpacingX = 40;
        int latticeSpacingY = 40;

        int latticeOriginX = origin.x + 3* latticeSpacingX;
        int numLatticeRows = ( fieldHeight - 1 ) / latticeSpacingY + 1;
        int latticeOriginY = origin.y - ( numLatticeRows / 2 ) * latticeSpacingY;
        Point latticeOrigin = new Point( latticeOriginX, latticeOriginY );
        fieldLatticeView = new FieldLatticeView( electron,
                                                 new Point( 0, 0 ),
//                                                 latticeOrigin,
                                                 fieldWidth - latticeSpacingX, fieldHeight,
                                                 latticeSpacingX,
                                                 latticeSpacingY );
        addGraphic( fieldLatticeView, 4 );

        StaticImageGraphic background = new StaticImageGraphic( "background.gif", 0, 150 );
        addGraphic( background, 0 );
        // todo: rjl 6/26/03
        model.addObserver( this );
//        EmfModel.instance().addObserver( this );
    }


    public void setFieldCurvesVisible( boolean enabled ) {
        fieldLatticeView.setFieldCurvesEnabled( enabled );
    }

    //
    // Static fields and methods
    //
    private static AntennaPanel s_instance;

    private static void setInstance( AntennaPanel panel ) {
        s_instance = panel;
    }

    public static AntennaPanel instance() {
        return s_instance;
    }

    public void setAutoscaleEnabled( boolean enabled ) {
        fieldLatticeView.setAutoscaleEnabled( enabled );
    }
}
