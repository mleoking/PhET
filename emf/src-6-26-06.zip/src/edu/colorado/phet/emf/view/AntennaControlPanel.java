/**
 * Class: AntennaControlPanel
 * Package: edu.colorado.phet.emf.view
 * Author: Another Guy
 * Date: May 27, 2003
 */
package edu.colorado.phet.emf.view;

import edu.colorado.phet.emf.AntennaModule;
import edu.colorado.phet.emf.command.*;
import edu.colorado.phet.emf.model.EmfModel;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

public class AntennaControlPanel extends JPanel implements Observer {

    private EmfModel model;
    private AntennaModule module;

    public AntennaControlPanel( EmfModel model, AntennaModule module ) {
        this.model = model;
        this.module = module;
        // todo: rjl 6/26/03
        model.addObserver( this );
//        EmfModel.instance().addObserver( this );
        createControls();
    }

    private void createControls() {
        this.setPreferredSize( new Dimension ( 150, 400 ));
//        this.add( new MovementControlPanel() );
        this.add( new OptionControlPanel() );
    }

    public void update( Observable o, Object arg ) {
    }


    //
    // Inner classes
    //


    /**
     * An inner class for the controls that enable, disable or set the values
     * of various options
     */
    private class OptionControlPanel extends JPanel {

        JCheckBox autoscaleCB = new JCheckBox( "Autoscale field vectors" );
        JCheckBox staticFieldCB = new JCheckBox( "Enable static field" );
        JCheckBox dynamicFieldCB = new JCheckBox( "Enable radiating field " );
        JCheckBox splineCurveCB = new JCheckBox( "Display curves" );
        JSlider freqSlider = new JSlider( 0, 300, 150 );
        JSlider ampSlider = new JSlider( 0, 100, 50 );

        OptionControlPanel() {
            this.setLayout( new GridLayout( 8, 1 ));

            this.add( autoscaleCB );
            autoscaleCB.addActionListener( new ActionListener() {
                public void actionPerformed( ActionEvent e ) {
                    new AutoscaleIsEnabledCmd( module, autoscaleCB.isSelected() ).doIt();
                }
            } );
            autoscaleCB.setSelected( true );

//            this.add( staticFieldCB );
//            staticFieldCB.addActionListener( new ActionListener() {
//                public void actionPerformed( ActionEvent e ) {
//                    new StaticFieldIsEnabledCmd( staticFieldCB.isSelected() ).doIt();
//                }
//            } );
//
//            this.add( dynamicFieldCB );
//            dynamicFieldCB.addActionListener( new ActionListener() {
//                public void actionPerformed( ActionEvent e ) {
//                    new DynamicFieldIsEnabledCmd( dynamicFieldCB.isSelected() ).doIt();
//                }
//            } );
//            dynamicFieldCB.setSelected( true );
//            new DynamicFieldIsEnabledCmd( dynamicFieldCB.isSelected() ).doIt();
//
//            this.add( splineCurveCB );
//            splineCurveCB.addActionListener( new ActionListener() {
//                public void actionPerformed( ActionEvent e ) {
//                    new SetFieldCurveEnabledCmd( splineCurveCB.isSelected() ).doIt();
//                }
//            } );

            this.add( new JLabel( "Frequency" ));
            this.add( freqSlider );
            freqSlider.setPreferredSize( new Dimension( 100, 20 ));
            freqSlider.addChangeListener( new ChangeListener() {
                public void stateChanged( ChangeEvent e ) {
                    new SetFreqencyCmd( model, (float)freqSlider.getValue() / 5000 ).doIt();
                }
            } );

            this.add( new JLabel( "Amplitude" ));
            this.add( ampSlider );
            ampSlider.setPreferredSize( new Dimension( 100, 20 ));
            ampSlider.addChangeListener(  new ChangeListener() {
                public void stateChanged( ChangeEvent e ) {
                    new SetAmplitudeCmd( model, (float)ampSlider.getValue() ).doIt();
                }
            } );
        }
    }

    /**
     * An inner class for the radio buttons that control how the transmitting
     * electrons move
     */
//    private class MovementControlPanel extends JPanel {
//
//        JRadioButton sineRB = new JRadioButton( "Sinusoidal movement" );
//        JRadioButton manualRB = new JRadioButton( "Manual control" );
//        ButtonGroup rbGroup = new ButtonGroup();
//
//        MovementControlPanel() {
//            this.setLayout( new GridLayout( 2, 1 ));
//            this.add( sineRB );
//            this.add( manualRB );
//            rbGroup.add( sineRB );
//            rbGroup.add( manualRB );
//            sineRB.setSelected( true );
//
//            sineRB.addActionListener( new ActionListener() {
//                public void actionPerformed( ActionEvent e ) {
//                    if( sineRB.isSelected() ) {
//                        module.setMovementSinusoidal();
//                    }
//                }
//            } );
//
//            manualRB.addActionListener( new ActionListener() {
//                public void actionPerformed( ActionEvent e ) {
//                    if( manualRB.isSelected() ) {
//                        module.setMovementManual();
//                    }
//                }
//            } );
//        }
//    }
}
