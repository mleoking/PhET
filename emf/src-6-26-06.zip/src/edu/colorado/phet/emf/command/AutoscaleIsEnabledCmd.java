/**
 * Class: AutoscaleIsEnabledCmd
 * Package: edu.colorado.phet.emf.command
 * Author: Another Guy
 * Date: Jun 13, 2003
 */
package edu.colorado.phet.emf.command;

import edu.colorado.phet.common.model.command.Command;
import edu.colorado.phet.emf.AntennaModule;
import edu.colorado.phet.emf.EmfModule;

public class AutoscaleIsEnabledCmd implements Command {
    private EmfModule module;
    private boolean isEnabled;

    public AutoscaleIsEnabledCmd( EmfModule module, boolean selected ) {
        this.module = module;
        this.isEnabled = selected;
    }

    public void doIt() {
        module.setAutoscaleEnabled( isEnabled );
    }
}
