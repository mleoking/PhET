/**
 * Created by IntelliJ IDEA.
 * User: Another Guy
 * Date: Feb 27, 2003
 * Time: 1:06:10 PM
 * To change this template use Options | File Templates.
 */
package edu.colorado.phet.physics.body;

import java.util.Observable;

public abstract class PhysicalEntity extends Observable {
    // List of contraints that must be applied to the Particle's state
    // at the end of each stepInTime
//    protected ArrayList constraints = new ArrayList();

//    public abstract void stepInTime( float  dt );

//    public void addConstraint( Constraint constraintSpec ) {
//        constraints.add( constraintSpec );
//    }
//
//    public void removeConstraint( Constraint constraintSpec ) {
//        constraints.remove( constraintSpec );
//    }
}
