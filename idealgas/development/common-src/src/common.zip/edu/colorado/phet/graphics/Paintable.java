package edu.colorado.phet.graphics;

import java.awt.*;

public interface Paintable {
    public void paint( Graphics2D g );
}
