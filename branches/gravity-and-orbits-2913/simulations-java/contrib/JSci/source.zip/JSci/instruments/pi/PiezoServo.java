package JSci.instruments.pi;

import JSci.instruments.*;

import java.io.*;

/** A Phisik Instrumente LVPZT amplifier/servo position controller,
 * attached to the PC through a RS232 port.
 */
public class PiezoServo extends DummyPositionControl {

    private RandomAccessFile rf;
    private String name;
    private int ttyNumber;
    private String type;
    private boolean inverted;

    /** the E-665 controller */
    public static final String E665="E-665";

    /** the E-662 controller */
    public static final String E662="E-662";

    /** @param n the number of the serial port (0,1,...) 
     * @param type the type of controller (E665, E662), see E665 and E662.
     * @param inverted the direction must be inverted?
     */
    public PiezoServo(int n,String type,boolean inverted) throws IOException {
	this.type=type;
	this.inverted=inverted;
	rf=new RandomAccessFile("/dev/ttyS"+n,"rw");
	ttyNumber=n;
	if (type.equals(E665)) write("SVO A1");
	write("*IDN?");
	name=read();
	if (!name.substring(0,2).equals("PI"))
	    throw new IOException("Serial device is unknown: "+name);
    }

    private void write(String s) throws IOException {
	rf.writeBytes(s);
	rf.writeByte(10);
	try {Thread.sleep(100);} catch (InterruptedException e) {}
    }

    private String read() throws IOException {
	String s="";
	byte b;
	while ((b=rf.readByte())!=10) s+=(char)b;
	return s;
    }

    public String toString() {
	return getClass().getName()+
            "[Port=/dev/ttyS"+ttyNumber+
            ",Controller="+name+"]";
    }

    protected final void doSetPosition(double z) {
	if (inverted) z=100.0-z;
	try {
	    if (type.equals(E665)) write("MOV A"+z);
	    if (type.equals(E662)) write("POS "+z);
	}
	catch (IOException e) {
	    System.err.println("Error writing to the "+name+": "+e);
	}
    }

    public void dispose() {
	try {rf.close();} catch (IOException e) {}
    }

    public double getActualPosition() {
	String v="";
	try {
	    if (type.equals(E665)) write("POS?A");
	    if (type.equals(E662)) write("POS?");
	    v=read();
	} catch (IOException e) {}
	double z = Double.valueOf(v).doubleValue();
	if (inverted) z=100.0-z;
        return z;
    }
    
    public void sleep() {
	try {Thread.sleep(300);} catch (InterruptedException e) {}
    }

    public static void main(String [] args) {
	PiezoServo p = null;
	try {
	    p = new PiezoServo(Integer.parseInt(args[0]),E665,false);
	    System.out.println(p);

	    System.out.println("Position: "+p.getActualPosition());
	    p.setPosition(3.0);
	    p.sleep();
	    System.out.println("Position: "+p.getActualPosition());
	    p.setPosition(6.0);
	    p.sleep();
	    System.out.println("Position: "+p.getActualPosition());
	    p.setPosition(9.0);
	    p.sleep();
	    System.out.println("Position: "+p.getActualPosition());
	}
	catch (IOException e) {
	    System.out.println(p.name+" error: "+e);
	}
	finally {
	    if (p!=null) p.dispose();
	}
    }

}
