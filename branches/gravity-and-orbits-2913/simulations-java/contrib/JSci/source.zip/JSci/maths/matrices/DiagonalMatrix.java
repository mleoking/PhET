package JSci.maths.matrices;

public interface DiagonalMatrix extends TridiagonalMatrix {}

