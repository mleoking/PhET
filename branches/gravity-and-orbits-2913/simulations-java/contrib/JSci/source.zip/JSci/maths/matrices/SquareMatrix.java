package JSci.maths.matrices;

public interface SquareMatrix {}

